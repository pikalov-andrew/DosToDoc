//---------------------------------------------------------------------------

#ifndef Unit2H
#define Unit2H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.ComCtrls.hpp>
//---------------------------------------------------------------------------
class TForm2 : public TForm
{
__published:	// IDE-managed Components
	TButton *BSaveParam;
	TButton *BUndoParam;
	TPageControl *PageControl1;
	TTabSheet *TabSheet1;
	TTabSheet *TabSheet2;
	TTabSheet *TabSheet3;
	TCheckBox *CAutoDel;
	TCheckBox *CAutoREgranOnOpen;
	TCheckBox *CAutoREgranOnPaste;
	TLabeledEdit *RowSymbols;
	TLabeledEdit *ColSymbols;
	TCheckBox *CAutoLimit;
	TCheckBox *CUnmergeBorders;
	TCheckBox *CCopyBorders;
	TCheckBox *CAutoSwapText;
	TCheckBox *CAutoMerge;
	TTabSheet *TabSheet4;
	TCheckBox *AllDoc;
	TCheckBox *CDoMacro;
	TLabeledEdit *MacroName;
	TCheckBox *OneDoc;
	TTabSheet *TabSheet5;
	TButton *ContWord;
	TButton *ResetCont;
	TCheckBox *CAutoFromWord;
	TCheckBox *CAutoExWordREgran;
	TComboBox *CMode;
	void __fastcall BSaveParamClick(TObject *Sender);
	void __fastcall BUndoParamClick(TObject *Sender);
	void __fastcall ResetContClick(TObject *Sender);

	void __fastcall ContWordClick(TObject *Sender);
	void __fastcall CModeSelect(TObject *Sender);
	void __fastcall CAutoREgranOnPasteClick(TObject *Sender);
	void __fastcall CAutoREgranOnOpenClick(TObject *Sender);
	void __fastcall CAutoFromWordClick(TObject *Sender);
	void __fastcall CAutoLimitClick(TObject *Sender);
	void __fastcall CAutoSwapTextClick(TObject *Sender);
	void __fastcall CAutoMergeClick(TObject *Sender);
	void __fastcall CCopyBordersClick(TObject *Sender);
	void __fastcall CAutoDelClick(TObject *Sender);
	void __fastcall CUnmergeBordersClick(TObject *Sender);
	void __fastcall AllDocClick(TObject *Sender);
	void __fastcall OneDocClick(TObject *Sender);
	void __fastcall CAutoExWordREgranClick(TObject *Sender);

private:	// User declarations
public:		// User declarations
	__fastcall TForm2(TComponent* Owner);
	void __fastcall Readini(bool def);
	void __fastcall Writeini(bool def);
	void __fastcall CheckBoxes();
};
//---------------------------------------------------------------------------
extern PACKAGE TForm2 *Form2;
//---------------------------------------------------------------------------
#endif

