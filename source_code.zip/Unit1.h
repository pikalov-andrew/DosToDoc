// ---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
// ---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ComCtrls.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Grids.hpp>
#include <Vcl.OleCtnrs.hpp>
#include <Vcl.Menus.hpp>
#include <Vcl.Dialogs.hpp>
#include <Vcl.ExtDlgs.hpp>
#include <Vcl.ButtonGroup.hpp>
#include <Vcl.ToolWin.hpp>
#include <System.ImageList.hpp>
#include <Vcl.ImgList.hpp>
#include <System.Actions.hpp>
#include <Vcl.ActnList.hpp>
#include <Vcl.StdActns.hpp>
#include <Vcl.ActnCtrls.hpp>
#include <Vcl.ActnMan.hpp>
#include <Vcl.ActnMenus.hpp>
#include <Vcl.PlatformDefaultStyleActnCtrls.hpp>
#include <Vcl.CustomizeDlg.hpp>
#include <Vcl.TitleBarCtrls.hpp>
#include <Vcl.WinXCtrls.hpp>
#include <Vcl.CheckLst.hpp>
#include <Vcl.ValEdit.hpp>
#include <Vcl.CategoryButtons.hpp>
#include <SHDocVw.hpp>
#include <Vcl.OleCtrls.hpp>
#include "SHDocVw_OCX.h"

// ---------------------------------------------------------------------------
class TForm1 : public TForm {
__published: // IDE-managed Components
	TRichEdit *RE;
	TPanel *PChangeTable;
	TStringGrid *SG;
	TStringGrid *SGokras;
	TPanel *PREgran;
	TRichEdit *REgran;
	TImageList *ImageSmall1;
	TRichEdit *REprov;
	TActionManager *ActionSmall1;
	TFileOpen *FileOpen1;
	TFileSaveAs *FileSaveAs1;
	TActionMainMenuBar *Menu;
	TAction *AClearRE;
	TFileExit *FileExit1;
	TStatusBar *StatusBar1;
	TPanel *PRE;
	TAction *ASettings;
	TAction *AModeNormal;
	TAction *AModeGran;
	TAction *AZoom200;
	TAction *AZoom100;
	TAction *AZoom50;
	TAction *AZoom150;
	TAction *Action8;
	TAction *AFontBig;
	TAction *AFontNormal;
	TAction *AFontSmall;
	TScrollBox *ScrollBox1;
	TPanel *Panel1;
	TLabel *Label1;
	TPanel *Panel2;
	TLabel *Label2;
	TActionToolBar *ActionToolBar2;
	TPanel *Panel3;
	TLabel *Label3;
	TActionToolBar *ActionToolBar3;
	TPanel *Panel4;
	TLabel *Label4;
	TActionToolBar *ActionToolBar4;
	TScrollBox *ScrollBox2;
	TPanel *Panel5;
	TLabel *Label5;
	TActionToolBar *ActionToolBar5;
	TPanel *Panel6;
	TLabel *Label6;
	TActionToolBar *ActionToolBar6;
	TMenuItem *N1;
	TMenuItem *NAddRow;
	TMenuItem *NAddCol;
	TMenuItem *N12;
	TMenuItem *N14;
	TMenuItem *N15;
	TMenuItem *N16;
	TMenuItem *N17;
	TMenuItem *N18;
	TMenuItem *N19;
	TMenuItem *N20;
	TMenuItem *N21;
	TAction *AAddRow;
	TAction *AAddCol;
	TAction *ADelRow;
	TAction *ADelCol;
	TPopupMenu *PopSG;
	TScrollBox *ScrollBox3;
	TPanel *Panel7;
	TLabel *Label7;
	TActionToolBar *ActionToolBar7;
	TActionManager *ActionBig2;
	TEditCut *EditCut1;
	TEditCopy *EditCopy1;
	TEditPaste *EditPaste1;
	TEditSelectAll *EditSelectAll1;
	TEditUndo *EditUndo1;
	TEditDelete *EditDelete1;
	TImageList *ImageBig1;
	TAction *ASpecialPaste;
	TAction *AIndentBig;
	TAction *AIndentNormal;
	TAction *AIndentSmall;
	TAction *ASmallIndentBig;
	TAction *ASmallIndentNormal;
	TAction *ASmallIndentSmall;
	TAction *ABigFontNormal;
	TActionToolBar *ActionToolBar8;
	TAction *ABigZoom100;
	TPanel *Panel8;
	TLabel *Label8;
	TActionToolBar *ActionToolBar1;
	TAction *AAddHor;
	TAction *AAddVert;
	TAction *ADelVert;
	TAction *ALimit;
	TAction *AUndo;
	TAction *ADelHor;
	TAction *ARedo;
	TAction *ADelText;
	TAction *AChangeTable;
	TAction *AChangePrivTable;
	TAction *AChangeNextTable;
	TAction *AMergeRow;
	TAction *AMergeCol;
	TAction *AMergeUndo;
	TAction *ADragUndo;
	TAction *AExWord;
	TSplitter *Splitter1;
	TPopupMenu *PopRE;
	TMenuItem *N2;
	TMenuItem *N3;
	TMenuItem *N8;
	TMenuItem *N9;
	TMenuItem *N10;
	TMenuItem *N11;
	TMenuItem *N13;
	TMenuItem *N22;
	TPopupMenu *PopREgran;
	TMenuItem *MenuItem1;
	TMenuItem *MenuItem2;
	TMenuItem *MenuItem3;
	TMenuItem *MenuItem4;
	TMenuItem *MenuItem5;
	TMenuItem *MenuItem6;
	TMenuItem *MenuItem7;
	TMenuItem *MenuItem8;
	TMenuItem *N4;
	TMenuItem *N5;
	TMenuItem *N6;
	TMenuItem *N7;
	TMenuItem *N23;
	TMenuItem *N24;
	TMenuItem *N25;
	TAction *AStatus;
	TAction *AMoveChanges;
	TTimer *Timer1;
	TTimer *Timer2;
	TTimer *Timer3;
	TAction *AClearSG;
	TMenuItem *N26;
	TMenuItem *N27;
	TAction *AWidthSGShort;
	TAction *AWidthSGFull;
	TAction *ASplit;
	TAction *AChangeHor;
	TAction *AAddColPriv;
	TAction *AAddColNext;
	TMenuItem *N28;
	TMenuItem *N29;
	TMenuItem *N30;
	TAction *AAllocCol;
	TAction *AAllocRow;
	TAction *AAllocAll;
	TMenuItem *N31;
	TAction *ASwapText;
	TAction *AMergeRect;
	TStringGrid *tempSG;
	TComboBox *ComboBox1;

	void __fastcall SGDrawCell(TObject *Sender, int ACol, int ARow, TRect &Rect,
		TGridDrawState State);
	void __fastcall PChangeTableResize(TObject *Sender);
	void __fastcall SGDragOver(TObject *Sender, TObject *Source, int X, int Y,
		TDragState State, bool &Accept);
	void __fastcall SGDragDrop(TObject *Sender, TObject *Source, int X, int Y);
	void __fastcall SGMouseDown(TObject *Sender, TMouseButton Button,
		TShiftState Shift, int X, int Y);
	void __fastcall SGKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
	void __fastcall SGContextPopup(TObject *Sender, TPoint &MousePos,
		bool &Handled);
    void __fastcall ClearHtml(TObject *Sender);
	void __fastcall defstyleRE(TObject *Sender);
	void __fastcall OneDocClick(TObject *Sender);
	void __fastcall FileOpen1Accept(TObject *Sender);
	void __fastcall AClearREExecute(TObject *Sender);
	void __fastcall AModeNormalExecute(TObject *Sender);
	void __fastcall AModeGranExecute(TObject *Sender);
	void __fastcall AZoom200Execute(TObject *Sender);
	void __fastcall AZoom150Execute(TObject *Sender);
	void __fastcall AZoom100Execute(TObject *Sender);
	void __fastcall AZoom50Execute(TObject *Sender);
	void __fastcall AFontBigExecute(TObject *Sender);
	void __fastcall AFontNormalExecute(TObject *Sender);
	void __fastcall AFontSmallExecute(TObject *Sender);
	void __fastcall FileSaveAs1Accept(TObject *Sender);
	void __fastcall ASettingsExecute(TObject *Sender);
	void __fastcall AAddHorExecute(TObject *Sender);
	void __fastcall AUndoExecute(TObject *Sender);
	void __fastcall AAddVertExecute(TObject *Sender);
	void __fastcall ALimitExecute(TObject *Sender);
	void __fastcall ADelVertExecute(TObject *Sender);
	void __fastcall ContextPopup(TObject *Sender, TPoint &MousePos,
		bool &Handled);
	void __fastcall MouseEnter(TObject *Sender);
	void __fastcall AMergeRowExecute(TObject *Sender);
	void __fastcall AMergeColExecute(TObject *Sender);
	void __fastcall AMergeUndoExecute(TObject *Sender);
	void __fastcall ADragUndoExecute(TObject *Sender);
	void __fastcall AExWordExecute(TObject *Sender);
	void __fastcall AIndentBigExecute(TObject *Sender);
	void __fastcall AIndentNormalExecute(TObject *Sender);
	void __fastcall AIndentSmallExecute(TObject *Sender);
	void __fastcall AChangeTableExecute(TObject *Sender);
	void __fastcall AChangePrivTableExecute(TObject *Sender);
	void __fastcall AChangeNextTableExecute(TObject *Sender);
	void __fastcall EditPaste1Execute(TObject *Sender);
	void __fastcall ASpecialPasteExecute(TObject *Sender);
	void __fastcall ADelTextExecute(TObject *Sender);
	void __fastcall AAddRowExecute(TObject *Sender);
	void __fastcall AAddColExecute(TObject *Sender);
	void __fastcall ADelColExecute(TObject *Sender);
	void __fastcall ADelRowExecute(TObject *Sender);
	void __fastcall ADelHorExecute(TObject *Sender);
	void __fastcall ARedoExecute(TObject *Sender);
	void __fastcall ARedoUpdate(TObject *Sender);
	void __fastcall FormCanResize(TObject *Sender, int &NewWidth,
		int &NewHeight, bool &Resize);
	void __fastcall FormResize(TObject *Sender);
	void __fastcall AStatusUpdate(TObject *Sender);
	void __fastcall REMouseUp(TObject *Sender, TMouseButton Button,
		TShiftState Shift, int X, int Y);
	void __fastcall AMoveChangesExecute(TObject *Sender);
	void __fastcall Timer1Timer(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall FileSaveAs1SaveDialogTypeChange(TObject *Sender);
	void __fastcall Timer2Timer(TObject *Sender);
	void __fastcall Timer3Timer(TObject *Sender);
	void __fastcall AClearSGExecute(TObject *Sender);
	void __fastcall N26Click(TObject *Sender);
	void __fastcall N27Click(TObject *Sender);
	void __fastcall AWidthSGShortExecute(TObject *Sender);
	void __fastcall AWidthSGFullExecute(TObject *Sender);
	void __fastcall REgranMouseWheel(TObject *Sender, TShiftState Shift, int WheelDelta,
          TPoint &MousePos, bool &Handled);
	void __fastcall REKeyUp(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall REMouseLeave(TObject *Sender);
	void __fastcall ASplitExecute(TObject *Sender);
	void __fastcall AChangeHorExecute(TObject *Sender);
	void __fastcall AAddColPrivExecute(TObject *Sender);
	void __fastcall AAddColNextExecute(TObject *Sender);
	void __fastcall AAllocRowExecute(TObject *Sender);
	void __fastcall AAllocColExecute(TObject *Sender);
	void __fastcall AAllocAllExecute(TObject *Sender);
	void __fastcall ASwapTextExecute(TObject *Sender);
	void __fastcall AMergeRectExecute(TObject *Sender);
	void __fastcall ComboBox1Select(TObject *Sender);


private:
	void virtual __fastcall WMDropFiles(TWMDropFiles &message);
	void virtual __fastcall FromWordOnCloseApp(TMessage &t);
	void virtual __fastcall FromWordOnOpenApp(TMessage &t);
	// User declarations
public: // User declarations
	enum TableChangeParam {
		normal, forward, back
	};
	BEGIN_MESSAGE_MAP
		MESSAGE_HANDLER(WM_DROPFILES,TWMDropFiles,WMDropFiles)
        MESSAGE_HANDLER(WM_USER+1,TMessage,FromWordOnOpenApp)
		MESSAGE_HANDLER(WM_USER+2,TMessage,FromWordOnCloseApp)
	END_MESSAGE_MAP(TForm);
	__fastcall TForm1(TComponent* Owner);
	int __fastcall preobrazovanie_tablic(TObject *Sender,
		TableChangeParam param);
	void __fastcall ochistka_tablic(TObject *Sender, TObject *Sender2);
	void __fastcall SelectNextTable();
	void __fastcall SelectPrivTable();
	void __fastcall automerge();
	void __fastcall savetomemgran();
	bool __fastcall simvolstroki(AnsiString);
	bool __fastcall simvolstolbca(AnsiString);
	void __fastcall perekras();
	void __fastcall proverka();
	void __fastcall zamenatab();
	void __fastcall zapolniteli();
    void __fastcall SGColWidth();
	void threadFunction();
	void __fastcall fAutoSizeColSG(TStringGrid * StringGrid) {

		int iTempColSize = 0; //
		int iMaxColSize = 0; //

		for (int j = 0; j <= StringGrid->ColCount - 1; j++) {
			for (int i = 0; i <= StringGrid->RowCount - 1; i++) {
				iTempColSize = StringGrid->Canvas->TextWidth
					(StringGrid->Cells[j][i]);
				if (iTempColSize > iMaxColSize) {
					iMaxColSize = iTempColSize;
				}
			}

			if (iMaxColSize == 0) {
				StringGrid->ColWidths[j] = 125;
			}
			else {
				StringGrid->ColWidths[j] =
					iMaxColSize + StringGrid->GridLineWidth + 10;
			}

			iTempColSize = 0; //
			iMaxColSize = 0;
		}
	}

};

// ---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
// ---------------------------------------------------------------------------
#endif
