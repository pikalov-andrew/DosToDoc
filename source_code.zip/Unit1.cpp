// ---------------------------------------------------------------------------
#include <StrUtils.hpp>
#include <vcl.h>
#include <Clipbrd.hpp>
#include <ComObj.hpp>
#include <utilcls.h>
#include "Unit1.h"
#include <memory>
#include "IniFiles.hpp"
#include "Unit2.h"
#include <thread>
#include <cstring>
#include <iostream>
#include <math.h>
#include <string>
#include <regex>
#include <mshtml.h>
#include <ctype.h>

using namespace std;
// ---------------------------------------------------------------------------
#pragma package(smart_init)

#pragma resource "*.dfm"
#pragma hdrstop
#define zoom(x,y,z) SendMessage( x, EM_SETZOOM, y, z )

TForm1 *Form1;
bool bildrop = false, firston = true, metkavis = true;
TStrings *simstr = new TStringList;
TStrings *simsto = new TStringList;
bool vstavka = false, formatvstavka = false;
TStrings *memregran = new TStringList;
TStrings *memchangetable = new TStringList;
int memkonec, memnachalo;
int memregrankonec, memregrannachalo;
Variant word_app, document, table, selection, range, paste_word,
	paste_selection;
AnsiString zapolnitelstroki, zapolnitelstolbca;
bool bilvizov = false;
int font_s = 10;
int indent = 15;
int defheight;
bool agdetablica = false;
bool metkaexword = false;
bool widthSGFullStyle = true;

AnsiString dopstroka(int kol, AnsiString a = " ") {
	AnsiString s = "test";
	s = "";
	for (int i = 1; i < kol; i++)
		s += a;
	return s;
}

void __fastcall TForm1::ClearHtml(TObject *Sender) {
	TRichEdit *RE = (TRichEdit*)Sender;
	// RE->Text = ReplaceStr(RE->Text, "<", "from");
	// RE->Text = ReplaceStr(RE->Text, ">", "to");
	AnsiString memtext = RE->Text;
	string textre = memtext.c_str();
	// std::regex expr("(from.*\n*.*to)");
	const regex pattern("\\<[^\\>]*\\>");
	// Use regex_replace function in regex
	// to erase every tags enclosed in <>
	textre = regex_replace(textre, pattern, "");
	const regex pattern2("MIME-Version.*");
	textre = regex_replace(textre, pattern2, "");
	const regex pattern3("Content-.*");
	textre = regex_replace(textre, pattern3, "");
	const regex pattern4("[-=]*_NextPart.*");
	textre = regex_replace(textre, pattern4, "" "");
	const regex pattern9
		("������ �������� �������� ���-��������� � ����� �����.*");
	textre = regex_replace(textre, pattern9, "");

	// const regex pattern5("\\&nbsp;");
	// textre = regex_replace(textre, pattern5, " ");
	// const regex pattern6("\\&lt;");
	// textre = regex_replace(textre, pattern6, """");
	// const regex pattern7("\\&gt;");
	// textre = regex_replace(textre, pattern7, """");
	// const regex pattern8("\\&quot;");
	// textre = regex_replace(textre, pattern8, "");
	memtext = textre.c_str();
	RE->Text = memtext;
	RE->Text = ReplaceStr(RE->Text, "&nbsp;", " ");
	RE->Text = ReplaceStr(RE->Text, "&lt;", "<");
	RE->Text = ReplaceStr(RE->Text, "&gt;", ">");
	RE->Text = ReplaceStr(RE->Text, "&quot;", "\"");
}

void __fastcall TForm1::defstyleRE(TObject *Sender) {
	TRichEdit *RE = (TRichEdit*)Sender;
	// PARAFORMAT2 paraformat;
	// ZeroMemory(&paraformat, sizeof(paraformat));
	// paraformat.cbSize = sizeof(PARAFORMAT2);
	// paraformat.dwMask = PFM_OFFSETINDENT | PFM_STARTINDENT | PFM_OFFSET | PFM_LINESPACING |
	// PFM_NUMBERING | PFM_NUMBERINGSTART | PFM_NUMBERINGSTYLE | PFM_NUMBERINGTAB;
	// paraformat.dySpaceBefore = 0;
	// paraformat.dySpaceBefore = 0;
	// SendMessage(RE->Handle, EM_SETPARAFORMAT, 0, Integer(&paraformat));

	if (RE->Text.Pos("<html>") || RE->Text.Pos("" "text/html" "")) {
		ClearHtml(RE);
	}
	for (int i = 0; i < RE->Lines->Count; i++) {
		if (RE->Lines->Strings[i] == "" || RE->Lines->Strings[i] == " ") {
			RE->Lines->Delete(i);
			i--;
		}
		else
			break;
	}
	RE->SelectAll();
	RE->SelAttributes->Name = "Consolas";
	RE->SelAttributes->Size = font_s;
	RE->Paragraph->FirstIndent = indent;
	RE->SelLength = 0;
	RE->ClearUndo();
}

void __fastcall TForm1::SelectNextTable() {
	int sellength = 0;
	memnachalo = memkonec;
	RE->SelStart = RE->Perform(EM_LINEINDEX, memnachalo, 0);
	if (memnachalo && memkonec != RE->Lines->Count) {
		memkonec++;
	}
	while (simvolstroki(RE->Lines->Strings[memkonec]) || simvolstolbca
		(RE->Lines->Strings[memkonec])) {
		memkonec++;
	}
	for (int i = memnachalo; i < memkonec; i++) {
		++sellength += RE->Lines->Strings[i].Length();
	}
	RE->SelLength = sellength + 1; // memkonec & memnachalo menyat
}

void __fastcall TForm1::SelectPrivTable() {
	int sellength = 0;
	RE->SelStart = RE->Perform(EM_LINEINDEX, memnachalo, 0);
	for (int i = memnachalo; i < memkonec; i++) {
		++sellength += RE->Lines->Strings[i].Length();
	}
	RE->SelLength = sellength;
}

void __fastcall TForm1::zapolniteli() {
	simstr->Clear();
	simsto->Clear();
	AnsiString s = Form2->RowSymbols->Text;
	while (s.Pos(",")) {
		simstr->Add(s.SubString(0, s.Pos(",") - 1));
		s = s.SubString(s.Pos(",") + 1, s.Length());
	}
	simstr->Add(s);
	zapolnitelstroki = s[1];
	s = Form2->ColSymbols->Text;
	while (s.Pos(",")) {
		simsto->Add(s.SubString(0, s.Pos(",") - 1));
		s = s.SubString(s.Pos(",") + 1, s.Length());
	}
	simsto->Add(s);
	zapolnitelstolbca = simsto->Strings[0][1];
}

// ---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner) : TForm(Owner) {
	RE->Zoom = 100;
	RE->Paragraph->FirstIndent = 15;
	REgran->Paragraph->FirstIndent = 15;

	if (ParamCount() == 0) {

		if (FileExists("last.txt")) {
			RE->Lines->LoadFromFile("last.txt");
			zamenatab();
		}
	}
	Splitter1->MinSize = PRE->Constraints->MinWidth + 15;
	AZoom100Execute(Owner);
	RE->MaxLength = 2147483632;
	REgran->MaxLength = RE->MaxLength;
	REprov->MaxLength = RE->MaxLength;
	defheight = RE->SelAttributes->Height;
}

int __fastcall TForm1::preobrazovanie_tablic(TObject *Sender,
	TableChangeParam param = normal) {
	int rowSG = 0, maxcolSG = 0, nachalo, konec;
	TRichEdit *REO = (TRichEdit*)Sender;
	nachalo = REO->Perform(EM_LINEFROMCHAR, REO->SelStart, 0);
	konec = REO->Perform(EM_LINEFROMCHAR,
		REO->SelStart + REO->SelLength - 1, 0);
	if (!PREgran->Visible) {
		switch (param) {

		case normal: {
				if (nachalo == konec || nachalo > konec) {
					nachalo = 0;
					bool puststr = false;
					for (int i = 0; i < REO->Lines->Count - 1; i++) {
						AnsiString s = REO->Lines->Strings[i];
						if (simvolstroki(REO->Lines->Strings[i])
							&& !simvolstroki(REO->Lines->Strings[i + 1])
							&& !simvolstolbca(REO->Lines->Strings[i + 1])) {
							puststr = true;
							konec = i + 1;
							break;
						}
					}
					if (!puststr) {
						konec = REO->Lines->Count;
					}

				}

			} break;
		case forward: {
				nachalo = memkonec;
				bool puststr = false;
				for (int i = nachalo; i < REO->Lines->Count - 1; i++) {
					AnsiString s = REO->Lines->Strings[i];
					if (simvolstroki(REO->Lines->Strings[i]) && !simvolstroki
						(REO->Lines->Strings[i + 1]) && !simvolstolbca
						(REO->Lines->Strings[i + 1])) {
						puststr = true;
						konec = i + 1;
						break;
					}
				}
				if (!puststr) {
					konec = REO->Lines->Count;
				}
			} break;
		case back: {
				konec = memnachalo;
				bool puststr = false;
				for (int i = konec; i > 0; i--) {
					AnsiString s = REO->Lines->Strings[i];
					if (simvolstroki(REO->Lines->Strings[i]) && !simvolstroki
						(REO->Lines->Strings[i - 1]) && !simvolstolbca
						(REO->Lines->Strings[i - 1])) {
						puststr = true;
						nachalo = i - 1;
						break;
					}
				}
				if (!puststr) {
					nachalo = 0;
				}
				if (nachalo == konec) {
					REO->SelStart = 0;
					REO->SelLength = 0;
					return 0;
				}
			} break;

		}
		AnsiString c = REO->Lines->Strings[konec];
		AnsiString cc = REO->Lines->Strings[konec + 1];
		if (simvolstroki(c) && !simvolstolbca(cc) && !simvolstroki(cc)) {
			konec++;
		}
	}
	else {
		konec = REgran->Lines->Count;
	}
	if (!PREgran->Visible) {
		memkonec = konec;
		memnachalo = nachalo;
	}
	else {
		memkonec = RE->Perform(EM_LINEFROMCHAR,
			RE->SelStart + RE->SelLength - 1, 0);
		memnachalo = RE->Perform(EM_LINEFROMCHAR, RE->SelStart, 0);
	}

	for (int rowcount = nachalo; rowcount <= konec; rowcount++) {
		UnicodeString pointrowRE = REO->Lines->Strings[rowcount];
		AnsiString s = pointrowRE;
		int *kolsimv, kolcell = 0, pointkolsimv = 0;
		if (simvolstroki(s)) {
			for (int i = 2; i < s.Length() + 1; i++) {
				if (simvolstolbca(s[i])) {
					kolcell++;
				}
			}
			if (maxcolSG < kolcell) {
				maxcolSG = kolcell;
				SG->ColCount = maxcolSG;
			}
			kolsimv = new int[kolcell];
			for (int i = 0; i < kolcell; i++) {
				kolsimv[i] = 0;
			}

			for (int i = 2; i < s.Length() + 1; i++) {
				if (simvolstolbca(s[i])) {
					pointkolsimv++;
					continue;
				}
				else
					kolsimv[pointkolsimv]++;
			}
			TStrings *strings = new TStringList;
			for (int i = 0; i < kolcell; i++) {
				strings->Add("");
			}
			rowcount++;
			pointrowRE = REO->Lines->Strings[rowcount];
			AnsiString ss = pointrowRE;
			bool sspos = simvolstroki(ss);
			while (!sspos && rowcount < REO->Lines->Count) {
				AnsiString ukor = ss.SubString(2, ss.Length() - 2);
				bool ssposs = simvolstolbca(ukor);
				if (ssposs) {
					pointkolsimv = 0;
					int position = 2;
					for (int i = 0; i < kolcell; i++) {
						AnsiString nevedom =
							ss.SubString(position + kolsimv[pointkolsimv], 1);
						if (!simvolstolbca(nevedom)) {
							AnsiString sss =
								ss.SubString(position,
								kolsimv[pointkolsimv] +
								kolsimv[pointkolsimv + 1] + 1);
							strings->Strings[i] += sss + " ";
							position += kolsimv[pointkolsimv] +
								kolsimv[pointkolsimv + 1] + 2;
							i++;
							pointkolsimv++;
						}
						else {
							AnsiString sss =
								ss.SubString(position, kolsimv[pointkolsimv]);
							strings->Strings[i] += sss + " ";
							position += kolsimv[pointkolsimv] + 1;
						}
						pointkolsimv++;
					}
				}
				else {
					strings->Strings[0] += ukor;
				}
				rowcount++;
				pointrowRE = REO->Lines->Strings[rowcount];
				ss = pointrowRE;
				sspos = simvolstroki(ss);
			}
			int cc = strings->Count;
			for (int i = 0; i < cc; i++) {
				for (int z = 0; z < simsto->Count; z++) {
					if (strings->Strings[i].Pos(simsto->Strings[z])) {
						strings->Strings[i] =
							ReplaceStr(strings->Strings[i],
							simsto->Strings[z], " ");
					}

				}
				UnicodeString repairstr =
					ReplaceStr(strings->Strings[i].Trim(), "   ", " ");
				while (repairstr.Pos("  ")) {
					repairstr = ReplaceStr(repairstr, "  ", " ");
				}
				SG->Cells[i][rowSG] = repairstr;
			}
			SG->RowCount++;
			rowSG++;
			rowcount--;
			strings->Clear();
		}

	}

	memchangetable->Clear();
	for (int rowcount = nachalo; rowcount <= konec; rowcount++) {
		memchangetable->Add(REO->Lines->Strings[rowcount]);
	}
	if (AModeGran->Checked) {
		ASwapText->Enabled = true;
	}
	else
		ASwapText->Enabled = false;

	int sellength = 0;
	REO->SelStart = REO->Perform(EM_LINEINDEX, nachalo, 0);
	for (int i = nachalo; i < konec + 1; i++) {
		++sellength += REO->Lines->Strings[i].Length();
	}
	REO->SelLength = sellength;
	REO->SetFocus();

	if (memkonec == REO->Lines->Count)
		AChangeNextTable->Enabled = false;
	else
		AChangeNextTable->Enabled = true;
	if (memnachalo == 0)
		AChangePrivTable->Enabled = false;
	else
		AChangePrivTable->Enabled = true;

	return maxcolSG;
}
bool success = false;

void __fastcall TForm1::ochistka_tablic(TObject *Sender, TObject *Sender2) {
	success = false;
	while (!success) {
		try {
			ADragUndo->Enabled = false;
			N21->Enabled = false;
			SG->RowCount++;
			SG->ColCount++;
			for (int i = 0; i < SG->ColCount; i++) {
				for (int j = 0; j < SG->RowCount; j++) {
					SG->Cells[i][j] = "";
				}
			}
			SG->RowCount = 1;
			SG->ColCount = 1;
			SGokras->RowCount++;
			SGokras->ColCount++;
			for (int i = 0; i < SGokras->ColCount; i++) {
				for (int j = 0; j < SGokras->RowCount; j++) {
					SGokras->Cells[i][j] = "";
				}
			}
			AExWord->Enabled = false;
			success = true;
		}
		catch (...) {
		}

	}
}

void __fastcall TForm1::savetomemgran() {
	memregran->Assign(REgran->Lines);
}

void __fastcall TForm1::zamenatab() {
	RE->Text = ReplaceStr(RE->Text, "\t", " ");
	REgran->Text = ReplaceStr(REgran->Text, "\t", " ");

}

void __fastcall TForm1::proverka() {

	TStrings *copyregran = new TStringList;
	copyregran->Assign(REgran->Lines);
	bool bil = false;
	for (int i = copyregran->Count - 1; i >= 0; i--) {
		if (copyregran->Strings[i] == "" || copyregran->Strings[i] == dopstroka
			(copyregran->Strings[i].Length() + 1, " ")) {
			copyregran->Delete(i);

		}
	}

	for (int i = 0; i <= copyregran->Count - 1; i++) {
		if (copyregran->Strings[i].Length()) {
			if (simvolstolbca
				(copyregran->Strings[i][copyregran->Strings[i].Length()])) {
				copyregran->Strings[i] =
					copyregran->Strings[i].SubString(0,
					copyregran->Strings[i].Length() - 1);
				i--;
			}
		}
	}
	if (copyregran->Count > 1) {
		if (!simvolstolbca(copyregran->Strings[0][1]) && simvolstolbca
			(copyregran->Strings[1][1])) {
			copyregran->Strings[0] =
				zapolnitelstolbca + copyregran->Strings[0].SubString(2,
				copyregran->Strings[0].Length() - 1);
		}
	}

	for (int i = 0; i <= copyregran->Count - 1; i++) {
		if (!simvolstolbca(copyregran->Strings[i][1])) {
			if (simvolstroki(copyregran->Strings[i][1])) {
				copyregran->Strings[i] =
					zapolnitelstolbca + copyregran->Strings[i].SubString(2,
					copyregran->Strings[i].Length());
			}
			else
				copyregran->Strings[i] =
					zapolnitelstolbca + copyregran->Strings[i];
		}
	}
	int max = 0;
	for (int i = 0; i <= copyregran->Count - 1; i++) {
		if (copyregran->Strings[i].Length() > max) {
			max = copyregran->Strings[i].Length();
		}
	}
	for (int i = 0; i <= copyregran->Count - 1; i++) {
		int k = copyregran->Strings[i].Length();
		if (k < max) {
			AnsiString dop = dopstroka(max - k + 1);
			copyregran->Strings[i] += dop;
		}
	}
	for (int i = 0; i <= copyregran->Count - 1; i++) {
		if (simvolstroki(copyregran->Strings[i])) {
			if (copyregran->Strings[i].Pos(" ")) {

				copyregran->Strings[i] = ReplaceStr(copyregran->Strings[i], " ",
					zapolnitelstroki);

			}
		}

	}
	bil = false;
	for (int i = 0; i <= copyregran->Count - 1; i++) {
		if (!simvolstolbca(copyregran->Strings[i][copyregran->Strings[i]
			.Length()])) {
			if (!bil) {
				bil = true;
			}
			copyregran->Strings[i] = copyregran->Strings[i] + zapolnitelstolbca;
		}
	}
	if (bil) {
		max++;
	}
	if (!simvolstroki(copyregran->Strings[0])) {
		copyregran->Insert(0, zapolnitelstolbca + dopstroka(max - 1,
			zapolnitelstroki) + zapolnitelstolbca);

	}

	if (!simvolstroki(copyregran->Strings[copyregran->Count - 1])) {
		copyregran->Insert(copyregran->Count,
			zapolnitelstolbca + dopstroka(max - 1, zapolnitelstroki) +
			zapolnitelstolbca);

	}
	if (copyregran->Strings[0].Length() > copyregran->Strings[1].Length()) {
		AnsiString s = copyregran->Strings[0];
		copyregran->Strings[0] = s.SubString(0, s.Length() - 3) +
			s.SubString(s.Length() - 1, s.Length());
	}
	else if (copyregran->Strings[0].Length() < copyregran->Strings[1].Length())
	{
		AnsiString s = copyregran->Strings[0];
		copyregran->Strings[0] = s.SubString(0, s.Length() - 3) +
			zapolnitelstroki + s.SubString(s.Length() - 2, s.Length());
	}
	if (copyregran->Strings[copyregran->Count - 1 - 1].Length() >
		copyregran->Strings[copyregran->Count - 1 - 2].Length()) {
		AnsiString s = copyregran->Strings[copyregran->Count - 1 - 1];
		copyregran->Strings[copyregran->Count - 1 - 1] =
			s.SubString(0, s.Length() - 3) + s.SubString(s.Length() - 1,
			s.Length());
	}
	else if (copyregran->Strings[copyregran->Count - 1 - 1].Length() <
		copyregran->Strings[copyregran->Count - 1 - 2].Length()) {

		AnsiString s = copyregran->Strings[copyregran->Count - 1 - 1];
		copyregran->Strings[copyregran->Count - 1 - 1] =
			s.SubString(0, s.Length() - 3) + zapolnitelstroki +
			s.SubString(s.Length() - 2, s.Length());
	}

	if (Form2->CCopyBorders->Checked) {
		for (int j = 0; j < copyregran->Count - 1; j++) {
			if (simvolstroki(copyregran->Strings[j])) {
				for (int i = 1; i < copyregran->Strings[j].Length() + 1; i++) {
					if (simvolstolbca(copyregran->Strings[j + 1][i])) {
						copyregran->Strings[j] =
							copyregran->Strings[j].SubString(1, i - 1) +
							zapolnitelstolbca + copyregran->Strings[j].SubString
							(i + 1, copyregran->Strings[j].Length());
					}
				}
			}
		}
		for (int i = 1; i < copyregran->Strings[copyregran->Count - 1].Length()
			+ 1; i++) {
			if (simvolstolbca(copyregran->Strings[copyregran->Count - 2][i])) {
				copyregran->Strings[copyregran->Count - 1] =
					copyregran->Strings[copyregran->Count - 1].SubString(1,
					i - 1) + zapolnitelstolbca +
					copyregran->Strings[copyregran->Count - 1].SubString(i + 1,
					copyregran->Strings[copyregran->Count - 1].Length());
			}
		}
	}

	for (int i = 2; i < max - 2; i++) {
		if (simvolstolbca(copyregran->Strings[1][i]) && !simvolstolbca
			(copyregran->Strings[0][i])) {
			AnsiString s = copyregran->Strings[0];
			s[i] = zapolnitelstolbca[1];
			copyregran->Strings[0] = s;
		}
	}

	for (int i = 2; i < copyregran->Strings[copyregran->Count - 1 - 2].Length()
		- 2; i++) {
		if (simvolstolbca(copyregran->Strings[copyregran->Count - 1 - 2][i])
			&& !simvolstolbca(copyregran->Strings[copyregran->Count - 1 -
			1][i])) {
			AnsiString s = copyregran->Strings[copyregran->Count - 1 - 1];
			s[i] = zapolnitelstolbca[1];
			copyregran->Strings[copyregran->Count - 1 - 1] = s;

		}
	}

	for (int i = 2; i < copyregran->Strings[0].Length() - 2; i++) {
		if (!simvolstolbca(copyregran->Strings[0][i]) && !simvolstolbca
			(copyregran->Strings[copyregran->Count - 1 - 1][i])) {
			continue;
		}
		for (int j = 1; j < copyregran->Count - 1 - 1; j++) {
			if (simvolstolbca(copyregran->Strings[j - 1][i]) && simvolstolbca
				(copyregran->Strings[j + 1][i]) && simvolstroki
				(copyregran->Strings[j].SubString(i, 2))) {
				copyregran->Strings[j] =
					copyregran->Strings[j].SubString(1, i - 1) +
					zapolnitelstolbca[1] + copyregran->Strings[j].SubString
					(i + 1, copyregran->Strings[j].Length());
			}
		}
	}

	for (int i = 1; i < copyregran->Strings[0].Length() - 2; i++) {

		if ((simvolstolbca(copyregran->Strings[0][i]) && simvolstolbca
			(copyregran->Strings[0][i + 1])) ||
			(simvolstolbca(copyregran->Strings[copyregran->Count - 1 - 1][i])
			&& simvolstolbca(copyregran->Strings[copyregran->Count - 1 -
			1][i + 1]))) {
			for (int j = 0; j < copyregran->Count - 1; j++) {
				AnsiString s = copyregran->Strings[j];
				copyregran->Strings[j] =
					s.SubString(0, i) + s.SubString(i + 2, s.Length());

			}
			i--;
		}

	}

	for (int i = 0; i < copyregran->Count - 1; i++) {
		if (simvolstroki(copyregran->Strings[i]) || !simvolstolbca
			(copyregran->Strings[i])) {
			continue;
		}
		bool pusto = true;
		for (int j = 1; j < copyregran->Strings[i].Length() - 2; j++) {
			char simb = copyregran->Strings[i][j];
			if (simvolstolbca(copyregran->Strings[i][j])) {
				continue;
			}
			if (!isspace(simb)) {
				pusto = false;
				break;
			}
		}
		if (pusto) {
			copyregran->Delete(i);
			i--;
		}
	}

	for (int j = 0; j < copyregran->Count - 2; j++) {
		if (simvolstroki(copyregran->Strings[j])) {
			int len = copyregran->Strings[j].Length();
			for (int i = 1; i < len; i++) {
				AnsiString ss = copyregran->Strings[j][i], sss =
					copyregran->Strings[j + 1][i], ssss =
					copyregran->Strings[j], sssss = copyregran->Strings[j + 1];

				if (simvolstolbca(ss) && !simvolstolbca(sss)) {

					int k = j + 1;
					while (!simvolstroki(copyregran->Strings[k]) && k <
						copyregran->Count - 2) {
						AnsiString govnishe = copyregran->Strings[k];
						k++;
					}

					if (k >= copyregran->Count - 2) {
						break;
					}

					if (!simvolstolbca(copyregran->Strings[k][i])) {
						AnsiString s = copyregran->Strings[j];
						copyregran->Strings[j] =
							s.SubString(0, i - 1) + zapolnitelstroki[1] +
							s.SubString(i + 1, s.Length());
					}
				}

			}
		}
	}

	for (int i = copyregran->Count - 1; i > 0; i--) {
		if (simvolstroki(copyregran->Strings[i]) && simvolstroki
			(copyregran->Strings[i - 1])) {
			copyregran->Delete(i);

		}
	}
	REgran->Lines->Assign(copyregran);
	defstyleRE(REgran);
}

bool __fastcall TForm1::simvolstroki(AnsiString s) {
	for (int i = 0; i < simstr->Count; i++) {
		if (s.Pos(simstr->Strings[i])) {
			return true;
		}
	}
	return false;
}

bool __fastcall TForm1::simvolstolbca(AnsiString s) {
	for (int i = 0; i < simsto->Count; i++) {
		if (s.Pos(simsto->Strings[i])) {
			return true;
		}
	}
	return false;
}

void __fastcall TForm1::automerge() {
	// if (SG->ColCount == 1 && SG->RowCount == 1) {
	// return;
	// }
	// for (int i = 0; i < SG->ColCount; i++) {
	// bool puststolbec = true;
	// for (int j = 0; j < SG->RowCount; j++) {
	// if (SG->Cells[i][j] != "") {
	// puststolbec = false;
	// break;
	// }
	// }
	// if (puststolbec) {
	// for (int j = 0; j < SG->RowCount; j++) {
	// if (i != SG->ColCount - 1) {
	// SG->Cells[i][j] = SG->Cells[i + 1][j];
	// }
	// else
	// break;
	// }
	// SG->Cols[SG->ColCount - 1]->Clear();
	// SG->ColCount--;
	// i--;
	// }
	// }
	// for (int i = 0; i < SG->ColCount; i++) {
	// for (int j = 0; j < SG->RowCount; j++) {
	// if (SG->Cells[i][j] == "") {
	// if (i == 0) {
	// bool puststr = true;
	// for (int k = 1; k < SG->ColCount; k++) {
	// if (SG->Cells[k][j] != "") {
	// puststr = false;
	// break;
	// }
	// }
	// if (puststr) {
	// for (int k = j; k < SG->RowCount - 1; k++) {
	// SG->Rows[k] = SG->Rows[k + 1];
	// }
	// SG->RowCount--;
	// j--;
	// }
	// else {
	// int stopslovo = j;
	// for (int k = j; k < SG->RowCount; k++) {
	// if (SG->Cells[i][k] != "") {
	// stopslovo = k;
	// break;
	// }
	// else if (k == SG->RowCount - 1) {
	// stopslovo = SG->RowCount;
	// }
	// }
	// for (int k = j - 1; k < stopslovo; k++) {
	// if (k == -1) {
	// continue;
	// }
	// SGokras->Cells[i][k] = "2";
	// }
	// }
	//
	// }
	// else if (i == 1) {
	// bool odna = true;
	// for (int k = 1; k < SG->ColCount; k++) {
	// if (SG->Cells[k][j] != "") {
	// odna = false;
	// }
	// }
	// if (odna) {
	// for (int k = 0; k < SG->ColCount; k++) {
	// SGokras->Cells[k][j] = "1";
	// }
	// }
	// }
	// else {
	// SGokras->Cells[i][j] = "1";
	// SGokras->Cells[i - 1][j] = "1";
	// }
	// }
	// }
	// }
	// for (int i = 0; i < SG->ColCount; i++) {
	// if (SG->Cells[i][1] == "") {
	// SGokras->Cells[i][0] = "2";
	// SGokras->Cells[i][1] = "2";
	// }
	// }
	//
	// perekras();

	if (SG->ColCount == 1 && SG->RowCount == 1) {
		return;
	}
	for (int i = 0; i < SG->ColCount; i++) {
		bool puststolbec = true;
		for (int j = 0; j < SG->RowCount; j++) {
			if (SG->Cells[i][j] != "") {
				puststolbec = false;
				break;
			}
		}
		if (puststolbec) {
			for (int j = 0; j < SG->RowCount; j++) {
				if (i != SG->ColCount - 1) {
					SG->Cells[i][j] = SG->Cells[i + 1][j];
				}
				else
					break;
			}
			SG->Cols[SG->ColCount - 1]->Clear();
			SG->ColCount--;
			i--;
		}
	}
	for (int i = 0; i < SG->ColCount; i++) {
		for (int j = 0; j < SG->RowCount; j++) {
			if (SG->Cells[i][j] == "") {
				if (i == 0) {
					bool puststr = true;
					for (int k = 1; k < SG->ColCount; k++) {
						if (SG->Cells[k][j] != "") {
							puststr = false;
							break;
						}
					}
					if (puststr) {
						for (int k = j; k < SG->RowCount - 1; k++) {
							SG->Rows[k] = SG->Rows[k + 1];
						}
						SG->RowCount--;
						j--;
					}
				}
			}
		}
	}
	SGokras->ColCount = SG->ColCount;
	SGokras->RowCount = SG->RowCount;
}

// ---------------------------------------------------------------------------

bool run = false;

void __fastcall TForm1::SGDrawCell(TObject * Sender, int ACol, int ARow,
	TRect & Rect, TGridDrawState State) {
	if (!State.Contains(gdSelected)) {
		if (SGokras->Cells[ACol][ARow] == "1") {
			TCanvas *a = this->SG->Canvas;
			a->Brush->Color = clMoneyGreen;
			a->FillRect(Rect);
			a->TextRect(Rect, Rect.left + 5, Rect.top + 5,
				this->SG->Cells[ACol][ARow]);
		}
		else if (SGokras->Cells[ACol][ARow] == "2") {
			TCanvas *a = this->SG->Canvas;
			a->Brush->Color = clWebLightPink;
			a->FillRect(Rect);
			a->TextRect(Rect, Rect.left + 5, Rect.top + 5,
				this->SG->Cells[ACol][ARow]);
		}
		else if (SGokras->Cells[ACol][ARow] == "3") {
			TCanvas *a = this->SG->Canvas;
			a->Brush->Color = clWebBurlywood;
			a->FillRect(Rect);
			a->TextRect(Rect, Rect.left + 5, Rect.top + 5,
				this->SG->Cells[ACol][ARow]);
		}
	}

}

void __fastcall TForm1::perekras() {
	if (SG->ColCount == 2) {
		for (int i = 0; i <= SG->RowCount; i++) {
			if ((SGokras->Cells[0][i] == "1" && SGokras->Cells[1][i] != "1") ||
				(SGokras->Cells[0][i] != "1" && SGokras->Cells[1][i] == "1")) {
				SGokras->Cells[0][i] = "0";
				SGokras->Cells[1][i] = "0";
			}
		}
	}
	else {
		for (int i = 0; i <= SG->ColCount - 1; i++) {
			for (int j = 0; j <= SG->RowCount; j++) {
				if (!i) {
					if (SGokras->Cells[i][j] == "1" && SGokras->Cells[i +
						1][j] != "1") {
						SGokras->Cells[i][j] = 0;
					}
					continue;
				}
				if (i && i != SG->ColCount - 1) {
					if (SGokras->Cells[i][j] == "1" && SGokras->Cells[i -
						1][j] != "1" && SGokras->Cells[i + 1][j] != "1") {
						SGokras->Cells[i][j] = 0;
					}
					continue;
				}
				if (i == SG->ColCount - 1) {
					if (SGokras->Cells[i][j] == "1" && SGokras->Cells[i -
						1][j] != "1") {
						SGokras->Cells[i][j] = 0;
					}
				}

			}
		}
	}
	for (int i = 0; i <= SG->ColCount; i++) {
		for (int j = 0; j <= SG->RowCount - 1; j++) {

			if (j) {
				if (SGokras->Cells[i][j] == "2" && SGokras->Cells[i][j -
					1] != "2" && SGokras->Cells[i][j + 1] != "2") {
					SGokras->Cells[i][j] = 0;
				}
			}
			else {
				if (SGokras->Cells[i][j] == "2" && SGokras->Cells[i][j +
					1] != "2") {
					SGokras->Cells[i][j] = 0;
				}
			}
		}
	}

	TGridRect hGridRect;
	hGridRect.Top = -1;
	hGridRect.Left = -1;
	hGridRect.Right = -1;
	hGridRect.Bottom = -1;
	SG->Selection = hGridRect;
	SG->Repaint();
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::SGColWidth() {
	if (widthSGFullStyle)
		SG->DefaultColWidth = (SG->Width - 30) / SG->ColCount;
	else
		fAutoSizeColSG(SG);
}

void __fastcall TForm1::PChangeTableResize(TObject * Sender) {
	SGColWidth();
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::SGDragOver(TObject * Sender, TObject * Source, int X,
	int Y, TDragState State, bool &Accept) {
	Accept = true;
}
// ---------------------------------------------------------------------------
int AColDrag, ARowDrag, memrdrop, memcdrop, memrdrag, memcdrag;
UnicodeString DragString, MemDrag, MemDrop;

void __fastcall TForm1::SGDragDrop(TObject * Sender, TObject * Source,
	int X, int Y)

{
	try {
		SG->MouseToCell(X, Y, AColDrag, ARowDrag);
		if (SG->Col == AColDrag && SG->Row == ARowDrag) {
			return;
		}
		memrdrop = ARowDrag;
		memcdrop = AColDrag;
		MemDrag = SG->Cells[AColDrag][ARowDrag];
		SG->Cells[AColDrag][ARowDrag] = SG->Cells[SG->Col][SG->Row];
		memrdrag = SG->Row;
		memcdrag = SG->Col;
		MemDrop = SG->Cells[SG->Col][SG->Row];
		bildrop = true;
		SG->Cells[SG->Col][SG->Row] = "";
		if (!bildrop) {
			ADragUndo->Enabled = false;
			N21->Enabled = false;
		}
		else {
			ADragUndo->Enabled = true;
			N21->Enabled = true;
		}
		ASwapText->Enabled = false;
	}
	catch (...) {
		ShowMessage("���������� ��������� �������");
	}

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::SGMouseDown(TObject * Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y) {

	if (Shift.Contains(ssAlt)) {
		SG->BeginDrag(true);
	}
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::SGKeyDown(TObject * Sender, WORD & Key,
	TShiftState Shift) {
	if (Shift.Contains(ssCtrl) && Key == 90 && bildrop && !Shift.Contains
		(ssAlt)) {
		SG->Cells[memcdrag][memrdrag] = MemDrop;
		SG->Cells[memcdrop][memrdrop] = MemDrag;
		bildrop = false;
		if (!bildrop) {
			ADragUndo->Enabled = false;
			N21->Enabled = false;
		}
		else {
			ADragUndo->Enabled = true;
			N21->Enabled = true;
		}
	}

}

// ---------------------------------------------------------------------------
bool bila4 = false;

void __fastcall TForm1::FormCloseQuery(TObject * Sender, bool &CanClose) {
	Form2->Writeini(false);
	if (FileExists(ExtractFilePath(Application->ExeName) + "last.txt")) {
		REprov->PlainText = false;
		REprov->Lines->LoadFromFile(ExtractFilePath(Application->ExeName) +
			"last.txt");
		if (RE->Text == REprov->Text) {
			bool odin = true;
			if (RE->Lines->Count < 500) {
				for (int i = 0; i < RE->Lines->Count; i++) {
					AnsiString s = RE->Lines->Strings[i], ss =
						REprov->Lines->Strings[i];
					if (s != ss) {

						odin = false;
						break;
					}
				}
				if (odin) {
					CanClose = true;
					return;
				}
			}
		}
	}
	else if (RE->Text == "") {
		CanClose = true;
		return;
	}
	SG->OnMouseEnter = NULL;
	RE->OnMouseEnter = NULL;
	RE->OnMouseEnter = NULL;

	switch (MessageBox(NULL, L"��������� ���� ��������� ������?",
		L"�������� ����������", MB_YESNOCANCEL + MB_ICONQUESTION +
		MB_TASKMODAL)) {
	case IDYES: {
			RE->PlainText = true;
			RE->Lines->SaveToFile(ExtractFilePath(ParamStr(0)) + "last.txt");

			CanClose = true;
		} break;
	case IDNO: {
			if (FileExists("last.txt")) {
				if (MessageBox(NULL, L"������� ���������� ����������� ����?",
					L"�������� ����������", MB_YESNO + MB_ICONQUESTION +
					MB_TASKMODAL) == IDYES) {
					DeleteFile(ExtractFilePath(Application->ExeName) +
						"last.txt");
				}

				CanClose = true;

			}

		} break;
	case IDCANCEL: {
			CanClose = false;
		} break;
	}
	SG->OnMouseEnter = MouseEnter;
	RE->OnMouseEnter = MouseEnter;
	RE->OnMouseEnter = MouseEnter;
}

// ---------------------------------------------------------------------------

void __fastcall TForm1::SGContextPopup(TObject * Sender, TPoint & MousePos,
	bool &Handled)

{
	try {
		if (SG->Selection.Top == SG->Selection.Bottom && SG->Selection.Left ==
			SG->Selection.Right) {
			int R, C;
			SG->MouseToCell(MousePos.X, MousePos.Y, C, R);

			TGridRect hGridRect;
			hGridRect.Top = R;
			hGridRect.Left = C;
			hGridRect.Right = hGridRect.Left;
			hGridRect.Bottom = hGridRect.Top;
			SG->Selection = hGridRect;
			Handled = false;
		}
	}
	catch (...) {
	};
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::OneDocClick(TObject * Sender) {
	if (Form2->OneDoc->Checked) {
		run = false;
	}
}
// ---------------------------------------------------------------------------
bool mode = true;

void __fastcall TForm1::FileOpen1Accept(TObject * Sender) {
	try {
		RE->Lines->LoadFromFile(FileOpen1->Dialog->FileName);
		AnsiString ext = ExtractFileExt(FileOpen1->Dialog->FileName);
		if (ext == ".rtf" || ext == ".RTF") {
			RE->PlainText = !RE->PlainText;
			RE->Lines->SaveToFile(ExtractFilePath(ParamStr(0)) + "temp.txt");
			RE->PlainText = !RE->PlainText;
			RE->Lines->LoadFromFile(ExtractFilePath(ParamStr(0)) + "temp.txt");
			DeleteFile(ExtractFilePath(Application->ExeName) + "temp.txt");
		}
	}
	catch (...) {
		ShowMessage(
			"��������� ������������ �����. ���������� ��������� ����� ���������.");
		return;
	}
	zamenatab();
	defstyleRE(RE);
	defstyleRE(REgran);
	memnachalo = 0;
	memkonec = 0;
	memregrannachalo = 0;
	memregrankonec = 0;
	if (Form2->CAutoDel->Checked) {
		ADelTextExecute(Form1);
	}
	AModeNormal->Checked = true;
	AModeNormalExecute(Form1);
	REMouseLeave(Sender);
	if (Form2->CAutoExWordREgran->Checked && Form2->AllDoc->Checked) {
		AExWordExecute(Sender);
	}
	else if (Form2->CAutoREgranOnOpen->Checked) {
		AModeGran->Checked = true;
		mode = true;
		AModeGranExecute(Sender);
	}
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AClearREExecute(TObject * Sender) {
	RE->Clear();
	REgran->Clear();
	ochistka_tablic(SG, SGokras);
	if (PREgran->Visible) {
		AModeNormal->Checked = true;
		AModeNormalExecute(Sender);
	}
	Form1->Repaint();
	memnachalo = 0;
	memkonec = 0;
	memregrannachalo = 0;
	memregrankonec = 0;
	// TAction* act = (TAction *) Sender;
	// ShowMessage(act->ActionComponent->Name);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AModeNormalExecute(TObject * Sender) {

	if (AModeNormal->Checked && !mode) {
		PREgran->Visible = false;
		PRE->Visible = true;
		mode = true;
		AChangeNextTable->Visible = true;
		AChangePrivTable->Visible = true;
		ADelText->Visible = true;
		int num, denom;
		SendMessage(REgran->Handle, EM_GETZOOM, (WPARAM) & num,
			(LPARAM) & denom);
		SendMessage(RE->Handle, EM_SETZOOM, (WPARAM) num, (LPARAM) denom);
		AMoveChanges->Visible = false;
		RE->SetFocus();
		Form1->Repaint();
	}

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AModeGranExecute(TObject * Sender) {
	if (AModeGran->Checked && mode) {
		if (!metkaexword && Form2->CAutoExWordREgran->Checked &&
			Form2->CAutoLimit->Checked) {
			AExWordExecute(Sender);
			return;
		}
		int nachalo = RE->Perform(EM_LINEFROMCHAR, RE->SelStart, 0);
		int konec = RE->Perform(EM_LINEFROMCHAR,
			RE->SelStart + RE->SelLength - 1, 0);
		if (nachalo == konec || nachalo > konec) {
			REgran->Lines->Assign(RE->Lines);
			RE->SelectAll();
		}
		else {
			REgran->Clear();
			////////////////////� ���� �� ������ ����������////////////////////////////
			wchar_t a[__WCHAR_MAX__];
			if (RE->SelLength < __WCHAR_MAX__) {
				RE->GetSelTextBuf(a, __WCHAR_MAX__);
				REgran->Text = a;
			}
			else {
				float f = RE->SelLength;
				f = round(f / __WCHAR_MAX__);
				for (int i = 0; i < f; i++) {
					RE->SelLength = __WCHAR_MAX__;
					RE->GetSelTextBuf(a, __WCHAR_MAX__);
					REgran->Text += a;
					RE->SelStart += RE->SelLength - 1;
				}
			}
		}

		defstyleRE(REgran);
		mode = false;
		AChangeNextTable->Visible = false;
		AChangePrivTable->Visible = false;
		ADelText->Visible = false;
		PREgran->Visible = true;
		PRE->Visible = false;
		int num, denom;
		SendMessage(RE->Handle, EM_GETZOOM, (WPARAM) & num, (LPARAM) & denom);
		SendMessage(REgran->Handle, EM_SETZOOM, (WPARAM) num, (LPARAM) denom);
		Form1->Repaint();
		AMoveChanges->Visible = true;
		REgran->SetFocus();
		if (!Form2->CAutoLimit->Checked && Form2->CUnmergeBorders->Checked) {
			ASplitExecute(Sender);
		}
		else if (Form2->CAutoLimit->Checked) {
			AChangeTableExecute(Sender);
		}

	}

}
// ---------------------------------------------------------------------------

//

// ---------------------------------------------------------------------------

void __fastcall TForm1::AZoom200Execute(TObject * Sender) {
	zoom(RE->Handle, 2, 1);
	zoom(REgran->Handle, 2, 1);
	StatusBar1->Panels->Items[2]->Text = "�������: 200%";
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AZoom150Execute(TObject * Sender) {
	zoom(RE->Handle, 3, 2);
	zoom(REgran->Handle, 3, 2);

	StatusBar1->Panels->Items[2]->Text = "�������: 150%";
}

// ---------------------------------------------------------------------------

void __fastcall TForm1::AZoom100Execute(TObject * Sender) {
	zoom(RE->Handle, 1, 1);
	zoom(REgran->Handle, 1, 1);

	StatusBar1->Panels->Items[2]->Text = "�������: 100%";
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AZoom50Execute(TObject * Sender) {
	zoom(RE->Handle, 1, 2);
	zoom(REgran->Handle, 1, 2);

	StatusBar1->Panels->Items[2]->Text = "�������: 50%";
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AFontBigExecute(TObject * Sender) {
	font_s = 14;
	defstyleRE(RE);
	defstyleRE(REgran);

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AFontNormalExecute(TObject * Sender) {
	font_s = 10;
	defstyleRE(RE);
	defstyleRE(REgran);

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AFontSmallExecute(TObject * Sender) {
	font_s = 6;
	defstyleRE(RE);
	defstyleRE(REgran);

}

// ---------------------------------------------------------------------------
void __fastcall TForm1::FileSaveAs1Accept(TObject * Sender) {
	RE->PlainText = !RE->PlainText;
	RE->Lines->SaveToFile(FileSaveAs1->Dialog->FileName);
	RE->PlainText = !RE->PlainText;
	FileSaveAs1->Dialog->FileName = "";
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::ASettingsExecute(TObject * Sender) {

	Form2->ShowModal();
	zapolniteli();
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::AAddHorExecute(TObject * Sender) {
	savetomemgran();
	AUndo->Enabled = true;
	int pred = REgran->Perform(EM_LINEFROMCHAR, REgran->SelStart, 0);
	int length = REgran->Lines->Strings[pred].Length();
	AnsiString s = "";
	for (int i = 0; i < length; i++) {
		s += "-";
	}
	if (pred == 0) {
		REgran->Lines->Insert(pred, s);
	}
	else
		REgran->Lines->Insert(pred + 1, s);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AUndoExecute(TObject * Sender) {
	REgran->Lines->Assign(memregran);
	defstyleRE(REgran);
	AUndo->Enabled = false;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AAddVertExecute(TObject * Sender) {
	savetomemgran();
	AUndo->Enabled = true;
	int pos = REgran->CaretPos.X;
	int posy = REgran->CaretPos.Y;
	TStrings *copyregran = new TStringList;
	copyregran->Assign(REgran->Lines);
	for (int i = 0; i < copyregran->Count; i++) {
		AnsiString s = copyregran->Strings[i];
		copyregran->Strings[i] = s.SubString(0, pos) + "|" +
			s.SubString(pos + 1, s.Length());
	}
	REgran->Lines->Assign(copyregran);
	defstyleRE(REgran);
	REgran->SelStart = REgran->Perform(EM_LINEINDEX, posy, 0) + pos;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::ALimitExecute(TObject * Sender) {
	savetomemgran();
	AUndo->Enabled = true;
	try {
		proverka();
	}
	catch (...) {
		ShowMessage("���������� ������������� ���������� �������");
	}
	Application->ProcessMessages();
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::ADelVertExecute(TObject * Sender) {
	savetomemgran();
	AUndo->Enabled = true;
	int pos = REgran->CaretPos.X;
	int posy = REgran->CaretPos.Y;
	TStrings *copyregran = new TStringList;
	copyregran->Assign(REgran->Lines);
	for (int i = 0; i < copyregran->Count; i++) {
		AnsiString s = copyregran->Strings[i];
		copyregran->Strings[i] = s.SubString(0, pos) + s.SubString(pos + 2,
			s.Length());
	}
	REgran->Lines->Assign(copyregran);
	defstyleRE(REgran);
	REgran->SelStart = REgran->Perform(EM_LINEINDEX, posy, 0) + pos;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::ContextPopup(TObject * Sender, TPoint & MousePos,
	bool &Handled)

{
	TRichEdit *RE = (TRichEdit*)Sender;
	if (!RE->SelLength) {
		long i;
		TPoint Tp;
		Tp.x = MousePos.x;
		Tp.y = MousePos.y;
		i = SendMessage(RE->Handle, EM_CHARFROMPOS, 0, (long) & Tp);
		RE->SelStart = i;
	}

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::MouseEnter(TObject * Sender) {
	TWinControl *T = (TWinControl*)Sender;
	T->SetFocus();
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AMergeRowExecute(TObject * Sender) {
	if (SG->Selection.Right == SG->Selection.Left) {
		ShowMessage("�������� ����� ����� ������ � ������");
		return;
	}
	for (int i = SG->Selection.Left; i <= SG->Selection.Right; i++) {
		for (int j = SG->Selection.Top; j <= SG->Selection.Bottom; j++) {
			SGokras->Cells[i][j] = 1;
		}
	}
	perekras();
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::AMergeColExecute(TObject * Sender) {
	if (SG->Selection.Top == SG->Selection.Bottom) {
		ShowMessage("�������� ����� ����� ������ � �������");
		return;
	}
	for (int i = SG->Selection.Left; i <= SG->Selection.Right; i++) {
		for (int j = SG->Selection.Top; j <= SG->Selection.Bottom; j++) {
			SGokras->Cells[i][j] = 2;
		}
	}
	perekras();
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AMergeUndoExecute(TObject * Sender) {
	try {
		bool gospodi = false;
		for (int i = SG->Selection.Left; i <= SG->Selection.Right; i++) {
			for (int j = SG->Selection.Top; j <= SG->Selection.Bottom; j++) {
				if (SGokras->Cells[i][j] == "3") {
					gospodi = true;
				}
				SGokras->Cells[i][j] = 0;
			}
		}
		if (gospodi) {
			for (int i = 0; i < SGokras->ColCount; i++) {
				for (int j = 0; j < SGokras->RowCount; j++) {
					if (SGokras->Cells[i][j] == "3") {
						SGokras->Cells[i][j] = 0;
					}
				}
			}
		}
		perekras();
	}
	catch (...) {
		ShowMessage("�� �������� �� ����� ������");
	}

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::ADragUndoExecute(TObject * Sender) {
	SG->Cells[memcdrag][memrdrag] = MemDrop;
	SG->Cells[memcdrop][memrdrop] = MemDrag;
	ADragUndo->Enabled = false;
	N21->Enabled = false;
}
// ---------------------------------------------------------------------------
bool progon = true;

void __fastcall TForm1::AExWordExecute(TObject * Sender) {
	metkaexword = true;
	if (Form2->OneDoc->Checked) {
		if (!run) {
			word_app = CreateOleObject("Word.Application");
			word_app.OlePropertyGet("Documents").OleProcedure("Add");
			document = word_app.OlePropertyGet("Documents").OleFunction
				("Item", 1);
			run = true;

		}

	}
	else {

		word_app = CreateOleObject("Word.Application");
		word_app.OlePropertyGet("Documents").OleProcedure("Add");
		document = word_app.OlePropertyGet("Documents").OleFunction("Item", 1);
	}
	if (Form2->AllDoc->Checked && progon) {
		if (Form2->CAutoLimit->Checked) {
			memnachalo = 0;
			memkonec = 0;
			memregrannachalo = 0;
			memregrankonec = 0;
			AChangeNextTableExecute(Sender);
			progon = false;
		}
	}
	int iCols = SG->ColCount;
	int iRows = SG->RowCount;
	try {
		selection = word_app.OlePropertyGet("Selection");
	}
	catch (...) {
		word_app = CreateOleObject("Word.Application");
		word_app.OlePropertyGet("Documents").OleProcedure("Add");
		document = word_app.OlePropertyGet("Documents").OleFunction("Item", 1);
		run = true;
		selection = word_app.OlePropertyGet("Selection");
	}
	word_app.OlePropertySet("Visible", false);
	if (Form2->OneDoc->Checked) {
		selection.OleProcedure("EndKey", 6);
		selection.OleProcedure("TypeParagraph");
	}
	range = selection.OlePropertyGet("Range");
	if (iCols > 46) {
		ShowMessage(
			"���������� ���������� ����� ������� Word ���������. ��������� ������� ����������.");
		word_app.OlePropertySet("Visible", true);
		selection.OleProcedure("WholeStory");
		Variant font = selection.OlePropertyGet("Font");
		font.OlePropertySet("Size", 14);
		WideString namew("Times New Roman");
		font.OlePropertySet("Name", namew.c_bstr());
		selection.OleProcedure("HomeKey", 6);
		word_app.OleProcedure("Activate");
		return;
	}
	table = document.OlePropertyGet("Tables").OleFunction("Add", range,
		iRows, iCols);
	for (int iGridRows = 1; iGridRows <= iRows; iGridRows++) {
		for (int iGridCols = 1; iGridCols <= iCols; iGridCols++) {
			Variant cell = table.OleFunction("Cell", iGridRows, iGridCols);
			cell.OlePropertyGet("Range").OlePropertySet("Text",
				WideString(SG->Cells[iGridCols - 1][iGridRows - 1]));
		}
	}
	try {
		for (int i = 0; i < SGokras->ColCount; i++) {
			for (int j = 0; j < SGokras->RowCount - 1; j++) {
				if (SGokras->Cells[i][j] == "2") {
					int firstcell = j;

					if (SG->Cells[i][j + 1] != "") {
						continue;
					}

					j++;
					int lastcell = j;

					while (SGokras->Cells[i][j + 1] == "2" && j <
						SGokras->RowCount - 1 && SG->Cells[i][j + 1] == "") {
						j++;
						lastcell = j;
					}

					table.OleFunction("Cell", firstcell + 1, i + 1).OleProcedure
						("Merge", table.OleFunction("Cell", lastcell + 1,
						i + 1));

				}
			}
		}
		for (int i = 0; i < SGokras->RowCount; i++) {
			int kolobed = 0;
			for (int j = 0; j < SGokras->ColCount - 1; j++) {
				if (SGokras->Cells[j][i] == "1") {
					int firstcell = j;
					j++;
					int lastcell = j;
					while (SGokras->Cells[j + 1][i] == "1" && j <
						SGokras->ColCount - 1 && SG->Cells[j + 1][i] == "") {
						j++;
						lastcell = j;
					}

					table.OleFunction("Cell", i + 1, firstcell + 1 - kolobed)
						.OleProcedure("Merge", table.OleFunction("Cell", i + 1,
						lastcell + 1 - kolobed));
					kolobed += lastcell - firstcell;
				}
			}
		}

		tempSG->ColCount = SG->ColCount;
		tempSG->RowCount = SG->RowCount;
		for (int i = 0; i < tempSG->ColCount; i++) {
			for (int j = 0; j < tempSG->RowCount; j++) {
				tempSG->Cells[i][j] = "";
			}
		}
		int iteratorobed = 1;

		for (int i = 0; i < SGokras->RowCount - 1; i++) {
			for (int j = 0; j < SGokras->ColCount - 1; j++) {
				if (SGokras->Cells[j][i] == "3" && tempSG->Cells[j][i] == "") {
					int kolobed = 0;
					int tempj = j, tempi = i;
					// ��������� ��������� ��� �� ����� ������
					for (int k = 0; k < j; k++) {
						int tempk = 0;
						if (SGokras->Cells[k][i] == "3") {
							tempk = k;
							AnsiString iteratorstr = tempSG->Cells[k][i];
							k++;

							while (SGokras->Cells[k][i] == "3" && tempSG->Cells
								[k][i] == iteratorstr) {
								k++;
							}
							kolobed += k - tempk - 1;
						}
						if (SGokras->Cells[k][i] == "1") {
							int firstcell = k;
							k++;
							int lastcell = k;
							while (SGokras->Cells[k + 1][i] == "1" && SG->Cells
								[k + 1][i] == "") {
								k++;
								lastcell = k;
							}

							kolobed += lastcell - firstcell;
						}
					}
					// ��� �� ����
					int firstcol = j;
					j++;
					int lastcol = j;
					while (SGokras->Cells[j + 1][i] == "3") {
						j++;
						lastcol = j;
					}
					int firstrow = i;
					i++;
					int lastrow = i;
					while (SGokras->Cells[j][i + 1] == "3" && SGokras->Cells
						[tempj][i + 1] == "3") {
						i++;
						lastrow = i;
					}

					table.OleFunction("Cell", firstrow + 1,
						firstcol + 1 - kolobed).OleProcedure("Merge",
						table.OleFunction("Cell", lastrow + 1,
						lastcol + 1 - kolobed));
					for (int k = tempj; k <= j; k++) {
						for (int h = tempi; h <= i; h++) {
							tempSG->Cells[k][h] = iteratorobed;
						}
					}
					iteratorobed++;
					i = tempi;

				}
			}
		}
	}
	catch (...) {
		ShowMessage("�� ������� ���������� ������ � �������.");
		WideString namew("True");
		document.OlePropertySet("Saved", namew.c_bstr());
		document.OleProcedure("Close");
		word_app.OleProcedure("Quit");
		return;
	}

	table.OlePropertyGet("Borders").OlePropertySet("InsideLineStyle", 1);
	table.OlePropertyGet("Borders").OlePropertySet("OutsideLineStyle", 1);
	if ((RE->Lines->Count - memkonec) > 2 && Form2->AllDoc->Checked) {
		if (!Form2->OneDoc->Checked) {

			if (Form2->CDoMacro->Checked && Form2->MacroName->Text != "") {
				WideString macrw(Form2->MacroName->Text);
				try {
					word_app.OleFunction("Run", macrw.c_bstr());
				}
				catch (...) {
					ShowMessage("������� � ����� ������ �� ����������");
				}

			}
			if (metkavis)
				word_app.OlePropertySet("Visible", true);
		}
		AChangeNextTableExecute(Sender);
		AExWordExecute(Sender);

	}
	else {

		if (Form2->CDoMacro->Checked && Form2->MacroName->Text != "") {
			WideString macrw(Form2->MacroName->Text);
			try {
				word_app.OleFunction("Run", macrw.c_bstr());
			}
			catch (...) {
				ShowMessage("������� � ����� ������ �� ����������");
			}

		}

		if (!Form2->OneDoc->Checked) {
			run = false;
		}
		progon = true;
		if (metkavis)
			word_app.OlePropertySet("Visible", true);
		selection.OleProcedure("WholeStory");
		Variant font = selection.OlePropertyGet("Font");
		font.OlePropertySet("Size", 14);
		WideString namew("Times New Roman");
		font.OlePropertySet("Name", namew.c_bstr());
		selection.OleProcedure("HomeKey", 6);
		if (metkavis)
			word_app.OleProcedure("Activate");
	}
	metkaexword = false;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AIndentBigExecute(TObject * Sender) {
	indent = 25;
	defstyleRE(RE);
	defstyleRE(REgran);

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AIndentNormalExecute(TObject * Sender) {
	indent = 15;
	defstyleRE(RE);
	defstyleRE(REgran);

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AIndentSmallExecute(TObject * Sender) {
	indent = 5;
	defstyleRE(RE);
	defstyleRE(REgran);

}

// ---------------------------------------------------------------------------
void __fastcall TForm1::AChangeTableExecute(TObject * Sender) {
	ochistka_tablic(SG, SGokras);

	AExWord->Enabled = false;
	int maxcolSG = 0;
	try {
		if (!PREgran->Visible) {
			maxcolSG = preobrazovanie_tablic(RE);
		}
		else {
			if (Form2->CUnmergeBorders->Checked) {
				ASplitExecute(Sender);
			}
			proverka();
			maxcolSG = preobrazovanie_tablic(REgran);
		}

	}
	catch (...) {
		SGColWidth();
		ShowMessage(
			"������� ���������� �����������. ��������� ���������� ������");

		return;
	}
	if (maxcolSG) {
		AExWord->Enabled = true;
	}
	else {
		ShowMessage("����������������� ������� �� �������.");
		ochistka_tablic(SG, SGokras);
		agdetablica = true;
		return;
	}

	SG->RowCount -= 2;
	SGokras->ColCount = SG->ColCount;
	SGokras->RowCount = SG->RowCount;
	if (Form2->CAutoSwapText->Checked && ASwapText->Enabled && PREgran->Visible)
	{
		ASwapTextExecute(Sender);
	}
	if (Form2->CAutoMerge->Checked) {
		automerge();
	}
	if (Form2->CAutoExWordREgran->Checked && (!Form2->AllDoc->Checked ||
		!Form2->CAutoLimit->Checked)) {
		AExWordExecute(Sender);
	}
	SGColWidth();
	TGridRect SelectedRect;
	SelectedRect.Left = 0;
	// ����� �������
	SelectedRect.Top = 0; // ������� �������
	SelectedRect.Right = 0; // ������ �������
	SelectedRect.Bottom = 0; // ������ �������
	SG->Selection = SelectedRect;

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AChangePrivTableExecute(TObject * Sender) {
	ochistka_tablic(SG, SGokras);
	int maxcolSG = 0;
	try {
		maxcolSG = preobrazovanie_tablic(RE, back);
	}
	catch (...) {
		ShowMessage(
			"���������� ���������� ������� ��������� �� �������. ��������� ���������� ������");
	}
	SelectPrivTable();

	if (maxcolSG) {
		AExWord->Enabled = true;

	}

	SG->RowCount -= 2;
	SGokras->ColCount = SG->ColCount;
	SGokras->RowCount = SG->RowCount;

	if (Form2->CAutoMerge->Checked) {
		automerge();
	}

	SGColWidth();
	TGridRect SelectedRect;
	SelectedRect.Left = 0;
	// ����� �������
	SelectedRect.Top = 0; // ������� �������
	SelectedRect.Right = 0; // ������ �������
	SelectedRect.Bottom = 0; // ������ �������
	SG->Selection = SelectedRect;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AChangeNextTableExecute(TObject * Sender) {
	ochistka_tablic(SG, SGokras);
	int maxcolSG = 0;

	if (Form2->AllDoc->Checked && Form2->CAutoExWordREgran->Checked) {
		SelectNextTable();
		AModeGran->Checked = true;
		mode = true;
		AModeGranExecute(Sender);
		AModeNormal->Checked = true;
		mode = false;
		AModeNormalExecute(Sender);
		return;
	}
	try {
		maxcolSG = preobrazovanie_tablic(RE, forward);
	}
	catch (...) {
		ShowMessage(
			"���������� ��������� ������� ��������� �� �������. ��������� ���������� ������");
	}
	if (maxcolSG) {
		AExWord->Enabled = true;

	}

	SG->RowCount -= 2;
	SGokras->ColCount = SG->ColCount;
	SGokras->RowCount = SG->RowCount;

	if (Form2->CAutoMerge->Checked) {
		automerge();
	}

	SGColWidth();
	TGridRect SelectedRect;
	SelectedRect.Left = 0;
	// ����� �������
	SelectedRect.Top = 0; // ������� �������
	SelectedRect.Right = 0; // ������ �������
	SelectedRect.Bottom = 0; // ������ �������
	SG->Selection = SelectedRect;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::EditPaste1Execute(TObject * Sender) {

	if (ActiveControl && ((TWinControl*)ActiveControl)->Name != "SG") {
		((TRichEdit*)ActiveControl)->PasteFromClipboard();
		int sel = ((TRichEdit*)ActiveControl)->SelStart;

		((TRichEdit*)ActiveControl)->SelStart = sel;
		((TRichEdit*)ActiveControl)->PlainText = !RE->PlainText;
		((TRichEdit*)ActiveControl)->Lines->SaveToFile
			(ExtractFilePath(ParamStr(0)) + "temp.txt");
		((TRichEdit*)ActiveControl)->PlainText = !RE->PlainText;
		((TRichEdit*)ActiveControl)->Lines->LoadFromFile
			(ExtractFilePath(ParamStr(0)) + "temp.txt");
		DeleteFile(ExtractFilePath(Application->ExeName) + "temp.txt");
		defstyleRE(RE);
		defstyleRE(REgran);
		zamenatab();
		memnachalo = 0;
		memkonec = 0;
		memregrannachalo = 0;
		memregrankonec = 0;
		if (Form2->CAutoDel->Checked) {
			ADelTextExecute(Sender);
		}
		if (Form2->CAutoExWordREgran->Checked && Form2->AllDoc->Checked) {
			AExWordExecute(Sender);
		}
		else if (Form2->CAutoREgranOnPaste->Checked && !PREgran->Visible) {
			AModeGran->Checked = true;
			mode = true;
			AModeGranExecute(Sender);
		}
	}
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::ASpecialPasteExecute(TObject * Sender) {
	if (ActiveControl && ((TWinControl*)ActiveControl)->Name != "SG") {
		((TRichEdit*)ActiveControl)->Clear();
		HANDLE clip;
		if (OpenClipboard(NULL)) {
			clip = GetClipboardData(CF_TEXT);
			CloseClipboard();
		}
		AnsiString stroka = (char*)clip;
		stroka += "\n";
		TStrings *strings = new TStringList;
		int pos = stroka.Pos("\n");
		while (pos && pos != 1) {
			strings->Add(stroka.SubString(0, stroka.Pos("\n")));
			stroka = stroka.SubString(stroka.Pos("\n") + 1, stroka.Length());
			pos = stroka.Pos("\n");
		}
		for (int i = 0; i < strings->Count; i++) {
			((TRichEdit*)ActiveControl)->Lines->Strings[i] =
				strings->Strings[i];
		}
		strings->Clear();

		((TRichEdit*)ActiveControl)->PlainText = !RE->PlainText;
		((TRichEdit*)ActiveControl)->Lines->SaveToFile
			(ExtractFilePath(ParamStr(0)) + "temp.txt");
		((TRichEdit*)ActiveControl)->PlainText = !RE->PlainText;
		((TRichEdit*)ActiveControl)->Lines->LoadFromFile
			(ExtractFilePath(ParamStr(0)) + "temp.txt");
		DeleteFile(ExtractFilePath(Application->ExeName) + "temp.txt");
		defstyleRE((TRichEdit*)ActiveControl);
		formatvstavka = false;
		zamenatab();
		if (Form2->CAutoDel->Checked) {
			ADelTextExecute(Sender);
		}
		if (Form2->CAutoExWordREgran->Checked && Form2->AllDoc->Checked) {
			AExWordExecute(Sender);
		}
		else if (Form2->CAutoREgranOnPaste->Checked) {
			AModeGran->Checked = true;
			mode = true;
			AModeGranExecute(Sender);
		}
	}
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::ADelTextExecute(TObject * Sender) {

	TStrings *copyregran = new TStringList;
	copyregran->Assign(RE->Lines);
	for (int i = copyregran->Count - 1; i >= 0; i--) {

		if (copyregran->Strings[i] == "") {
			continue;
		}
		if ((!simvolstolbca(copyregran->Strings[i]) && !simvolstroki
			(copyregran->Strings[i]))) {
			copyregran->Strings[i] = "";
		}
	}
	for (int i = copyregran->Count - 1; i >= 1; i--) {
		if (copyregran->Strings[i] == "" && copyregran->Strings[i - 1] == "") {
			copyregran->Delete(i);
		}
	}
	if (copyregran->Strings[0] == "") {
		copyregran->Delete(0);
	}
	if (copyregran->Strings[copyregran->Count - 1] == "") {
		copyregran->Delete(copyregran->Count - 1);
	}
	RE->Lines->Assign(copyregran);
	defstyleRE(REgran);
	REMouseLeave(Sender);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AAddRowExecute(TObject * Sender) {

	SG->RowCount++;
	SGokras->RowCount++;
	for (int i = SG->RowCount; i > SG->Row + 1; i--) {
		SG->Rows[i] = SG->Rows[i - 1];
		SGokras->Rows[i] = SGokras->Rows[i - 1];

	}
	SG->Rows[SG->Row + 1]->Clear();
	SGokras->Rows[SG->Row + 1]->Clear();
	perekras();
	PChangeTableResize(Sender);

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AAddColExecute(TObject * Sender) {
	SG->ColCount++;
	SGokras->ColCount++;
	for (int i = SG->ColCount; i > SG->Col + 1; i--) {
		SG->Cols[i] = SG->Cols[i - 1];
		SGokras->Cols[i] = SGokras->Cols[i - 1];

	}
	SG->Cols[SG->Col + 1]->Clear();
	SGokras->Cols[SG->Col + 1]->Clear();
	perekras();
	PChangeTableResize(Sender);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::ADelColExecute(TObject * Sender) {

	if (SG->ColCount == 1) {
		ShowMessage("������ ������� ������������ �������");
		return;
	}
	int j = SG->Selection.Right - SG->Selection.Left;
	for (int i = 0; i <= j; i++) {

		for (int i = SG->Col; i < SG->ColCount - 1; i++) {
			SG->Cols[i] = SG->Cols[i + 1];
			SGokras->Cols[i] = SGokras->Cols[i + 1];
		}
		SG->ColCount--;
		SGokras->ColCount--;
	}
	PChangeTableResize(Sender);
	perekras();
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::ADelRowExecute(TObject * Sender) {
	if (SG->RowCount == 1) {
		ShowMessage("������ ������� ������������ ������");
		return;
	}
	int j = SG->Selection.Bottom - SG->Selection.Top;
	for (int i = 0; i <= j; i++) {
		for (int i = SG->Row; i < SG->RowCount - 1; i++) {
			SG->Rows[i] = SG->Rows[i + 1];
			SGokras->Rows[i] = SGokras->Rows[i + 1];
		}
		SG->RowCount--;
		SGokras->RowCount--;
	}
	PChangeTableResize(Sender);
	perekras();
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::ADelHorExecute(TObject * Sender) {
	REgran->Lines->Delete(REgran->Perform(EM_LINEFROMCHAR,
		REgran->SelStart, 0));
}

int CountUndoRE = 0, CountUndoREgran = 0;

void __fastcall TForm1::ARedoExecute(TObject * Sender) {
	if (SendMessage(ActiveControl->Handle, EM_CANREDO, 0, 0)) {
		SendMessage(ActiveControl->Handle, EM_REDO, 0, 0);
	}

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::ARedoUpdate(TObject * Sender) {

	if (ActiveControl) {
		if (SendMessage(ActiveControl->Handle, EM_CANREDO, 0, 0)) {
			ARedo->Enabled = true;
		}
		else
			ARedo->Enabled = false;
	}

}
// ---------------------------------------------------------------------------
float widre;

void __fastcall TForm1::FormCanResize(TObject * Sender, int &NewWidth,
	int &NewHeight, bool &Resize) {
	if (AModeNormal->Checked) {
		widre = (float)Form1->Width / PRE->Width;
	}
	else {
		widre = (float)Form1->Width / PREgran->Width;
	}

}

// ---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject * Sender) {
	if (AModeNormal->Checked) {
		PRE->Width = Form1->Width / widre;
		PChangeTable->Width = Form1->Width - PRE->Width - Splitter1->Width - 31;
	}
	else {
		PREgran->Width = Form1->Width / widre;
		PChangeTable->Width = Form1->Width - PREgran->Width -
			Splitter1->Width - 31;
	}
	Splitter1->Align = alNone;
	Splitter1->Align = alRight;
	ComboBox1->Left = Form1->Width - ComboBox1->Width - 25;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AStatusUpdate(TObject * Sender) {

	// if (ActiveControl) {
	//
	// if (((TWinControl*)ActiveControl)->Name == "RE" ||
	// ((TWinControl*)ActiveControl)->Name == "REgran") {
	// AnsiString s = "";
	// int x = ((TRichEdit*)ActiveControl)->CaretPos.X, y =
	// ((TRichEdit*)ActiveControl)->CaretPos.Y;
	// s += "������: " + IntToStr(y + 1);
	// s += " ������: " + IntToStr(x + 1);
	// StatusBar1->Panels->Items[1]->Text = s;
	// }
	// else
	// StatusBar1->Panels->Items[1]->Text = "";
	// if (((TWinControl*)ActiveControl)->Name == "RE" ||
	// ((TWinControl*)ActiveControl)->Name == "REgran") {
	// int num, denom;
	// SendMessage(ActiveControl->Handle, EM_GETZOOM, (WPARAM) & num,
	// (LPARAM) & denom);
	// if (num && denom)
	// StatusBar1->Panels->Items[2]->Text =
	// "�������: " + FloatToStr(num * 100 / denom) + "%";
	//
	// }
	//
	// for (int i = 0; i < StatusBar1->Panels->Count; i++) {
	// StatusBar1->Panels->Items[i]->Width =
	// Canvas->TextWidth(StatusBar1->Panels->Items[i]->Text) + 35;
	// }
	// bool text = false;
	// for (int i = 0; i < RE->Lines->Count; i++) {
	// if (!simvolstroki(RE->Lines->Strings[i]) && !simvolstolbca
	// (RE->Lines->Strings[i])) {
	// AnsiString s = RE->Lines->Strings[i];
	// if (s != "") {
	// text = true;
	// break;
	// }
	// }
	// }
	// if (text) {
	//
	// AChangeNextTable->Enabled = false;
	// AChangePrivTable->Enabled = false;
	// if (!((TRichEdit*)ActiveControl)->SelLength) {
	// AChangeTable->Enabled = false;
	// }
	// if (PREgran->Visible) {
	// AChangeTable->Enabled = true;
	// }
	// ADelText->Enabled = true;
	// StatusBar1->Panels->Items[3]->Text =
	// "��� �������������� ��������� ���������� ������� �����";
	//
	// }
	// else {
	// AChangeTable->Enabled = true;
	// if (memkonec == RE->Lines->Count)
	// AChangeNextTable->Enabled = false;
	// else {
	// bool abool = false;
	// for (int i = memkonec; i < RE->Lines->Count; i++) {
	// if (simvolstroki(RE->Lines->Strings[i])) {
	// abool = true;
	// break;
	// }
	// }
	// if (abool) {
	// AChangeNextTable->Enabled = true;
	// }
	// else {
	// AChangeNextTable->Enabled = false;
	// }
	//
	// }
	// if (memnachalo == 0)
	// AChangePrivTable->Enabled = false;
	// else
	// AChangePrivTable->Enabled = true;
	// if (Form2->AllDoc->Checked) {
	// AExWord->Enabled = true;
	// }
	// ADelText->Enabled = false;
	// StatusBar1->Panels->Items[3]->Text = "";
	//
	// }
	// }

	// thread thr(threadFunction);
	// thr.detach();

}

// ---------------------------------------------------------------------------
void __fastcall TForm1::REMouseUp(TObject * Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y) {

	if (((TRichEdit*)Sender)->SelLength) {
		AChangeTable->Enabled = true;
	}
	if (((TWinControl*)ActiveControl)->Name == "RE" ||
		((TWinControl*) ActiveControl)->Name == "REgran") {
		AnsiString s = "";
		int x = ((TRichEdit*)ActiveControl)->CaretPos.X, y =
			((TRichEdit*)ActiveControl)->CaretPos.Y;
		s += "������: " + IntToStr(y + 1);
		s += " ������: " + IntToStr(x + 1);
		StatusBar1->Panels->Items[1]->Text = s;
	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::AMoveChangesExecute(TObject * Sender) {
	REgran->SelectAll();
	REgran->SelLength--;
	REgran->CopyToClipboard();
	RE->PasteFromClipboard();
	AModeNormal->Checked = true;
	AModeNormalExecute(Sender);
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::Timer1Timer(TObject * Sender) {
	if (firston) {
		SGColWidth();
		REMouseLeave(Sender);
		firston = false;
		Timer1->Enabled = false;
		if (ParamCount() == 0) {
			return;
		}

		int i = 1;
		while (ParamStr(i) != "") {
			AnsiString ext = ExtractFileExt(ParamStr(i));
			if (ext == ".txt" || ext == ".TXT" || ext == ".RTF" ||
				ext == ".rtf") {
				RE->Lines->LoadFromFile(ParamStr(i));
				if (ext == ".rtf" || ext == ".RTF") {
					RE->PlainText = !RE->PlainText;
					RE->Lines->SaveToFile(ExtractFilePath(ParamStr(0)) +
						"temp.txt");
					RE->PlainText = !RE->PlainText;
					RE->Lines->LoadFromFile(ExtractFilePath(ParamStr(0)) +
						"temp.txt");
					DeleteFile(ExtractFilePath(Application->ExeName) +
						"temp.txt");
				}
				zamenatab();
				defstyleRE(RE);
				if (Form2->CAutoDel->Checked) {
					ADelTextExecute(Sender);
				}
				if (Form2->CAutoREgranOnOpen->Checked) {
					AModeGran->Checked = true;
					mode = true;
					AModeGranExecute(Sender);
				}
				else {
					if (Form2->AllDoc->Checked) {
						AExWordExecute(Sender);
					}
				}
				if (Form2->AllDoc->Checked) {
					i++;
					if (ParamStr(i) != "") {
						word_app.OlePropertyGet("Documents").OleProcedure
							("Add");
						document = word_app.OlePropertyGet("Documents")
							.OleFunction("Item", 1);
					}
				}
				else
					return;

			}
			else
				i++;
		}
	}
	else {
		if (ParamCount() > 1) {
			ShowMessage(
				"��� �������������� ��������� ���������� ���������� ���������� �������� ������ ��������:\n������������� ��������������� ��� ������� � ���������\n��� �������� ��������� ������������� ������� ����� ���������� �������");
		}
		AnsiString ext = ExtractFileExt(ParamStr(1));

		if (ext == ".txt" || ext == ".rtf" || ext == ".RTF" || ext == ".TXT") {
			RE->Lines->LoadFromFile(ParamStr(1));
			if (ext == ".rtf" || ext == ".RTF") {
				RE->PlainText = !RE->PlainText;
				RE->Lines->SaveToFile(ExtractFilePath(ParamStr(0)) +
					"temp.txt");
				RE->PlainText = !RE->PlainText;
				RE->Lines->LoadFromFile(ExtractFilePath(ParamStr(0)) +
					"temp.txt");
				DeleteFile(ExtractFilePath(Application->ExeName) + "temp.txt");
			}
			zamenatab();
			defstyleRE(RE);
		}
		if (Form2->CAutoDel->Checked) {
			ADelTextExecute(Sender);
		}
		if (Form2->CAutoREgranOnOpen->Checked) {
			AModeGran->Checked = true;
			mode = true;
			AModeGranExecute(Sender);
		}
		else {
			if (Form2->AllDoc->Checked) {
				AExWordExecute(Sender);
			}
		}
	}
}

// ---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject * Sender) {
	DragAcceptFiles(Form1->Handle, true);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::FormDestroy(TObject * Sender) {
	DragAcceptFiles(Form1->Handle, false);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::WMDropFiles(TWMDropFiles & message) {
	char chName[MAX_PATH];
	HDROP hdropHandle = (HDROP)message.Drop;
	// get numbers of dragging files
	// int viNumber=DragQueryFile(hdropHandle,-1,NULL,NULL);
	DragQueryFile(hdropHandle, 0, (LPWSTR)chName, MAX_PATH);
	RE->Clear();
	RE->Lines->LoadFromFile((LPWSTR)chName);
	AnsiString prov = (LPWSTR)chName;
	if (prov.Pos(".rtf") || prov.Pos(".RTF")) {
		RE->PlainText = !RE->PlainText;
		RE->Lines->SaveToFile(ExtractFilePath(ParamStr(0)) + "temp.txt");
		RE->PlainText = !RE->PlainText;
		RE->Lines->LoadFromFile(ExtractFilePath(ParamStr(0)) + "temp.txt");
		DeleteFile(ExtractFilePath(Application->ExeName) + "temp.txt");
	}
	zamenatab();
	defstyleRE(RE);

	if (Form2->CAutoDel->Checked) {
		ADelTextExecute(Form1);
	}
	if (Form2->CAutoREgranOnOpen->Checked) {
		AModeGran->Checked = true;
		mode = true;
		AModeGranExecute(Form1);
	}
	else {
		if (Form2->AllDoc->Checked) {
			AExWordExecute(Form1);
		}
	}

}
HWND win_handle;

void __fastcall TForm1::FromWordOnCloseApp(TMessage & t) {

	Timer2->Enabled = true;
	return;
}

void __fastcall TForm1::FromWordOnOpenApp(TMessage & t) {

	Timer3->Enabled = true;
	return;
}

void __fastcall TForm1::FileSaveAs1SaveDialogTypeChange(TObject * Sender) {
	switch (FileSaveAs1->Dialog->FilterIndex) {
	case 1:
		FileSaveAs1->Dialog->DefaultExt = "txt";
		break;
	case 2:
		FileSaveAs1->Dialog->DefaultExt = "rtf";
		break;
	case 3:
		FileSaveAs1->Dialog->DefaultExt = "";
		break;
	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::Timer2Timer(TObject * Sender) {
	if (Timer2->Enabled) {
		metkavis = false;
		Timer2->Enabled = false;
		HWND hWnd = GetForegroundWindow();
		bool neudalos = false;
		try {
			paste_word = GetActiveOleObject("Word.Application");
			paste_selection = paste_word.OlePropertyGet("Selection");
		}
		catch (...) {
			neudalos = true;
		}
		RE->Clear();
		RE->PasteFromClipboard();
		RE->PlainText = !RE->PlainText;
		RE->Lines->SaveToFile(ExtractFilePath(ParamStr(0)) + "temp.txt");
		RE->PlainText = !RE->PlainText;
		RE->Lines->LoadFromFile(ExtractFilePath(ParamStr(0)) + "temp.txt");
		DeleteFile(ExtractFilePath(Application->ExeName) + "temp.txt");
		AIndentNormalExecute(Sender);
		AFontNormalExecute(Sender);
		if (!Form2->CAutoFromWord->Checked) {
			return;
		}
		if (Form2->CAutoDel->Checked) {
			ADelTextExecute(Sender);
		}
		if (Form2->CAutoREgranOnOpen->Checked) {
			AModeGran->Checked = true;
			mode = true;
			AModeGranExecute(Sender);
		}
		else {
			if (Form2->AllDoc->Checked) {
				AExWordExecute(Sender);
			}
			else {
				RE->SelectAll();
				AChangeTableExecute(Form1);
				if (agdetablica) {
					agdetablica = false;
					return;
				}
				AExWordExecute(Form1);
			}
		}

		selection.OleProcedure("WholeStory");
		selection.OleProcedure("Cut");
		WideString namew("True");
		document.OlePropertySet("Saved", namew.c_bstr());
		document.OleProcedure("Close");
		word_app.OleProcedure("Quit");
		if (neudalos) {
			Sleep(300);
			ShowMessage("������� ������ � �������");
			SetForegroundWindow(hWnd);
			return;
		}
		bool exception = true;
		while (exception) {
			try {
				Sleep(15);
				paste_selection.OleProcedure("PasteAndFormat", 16);
				exception = false;
			}
			catch (...) {
			}
		}
		// , L"wdFormatOriginalFormatting");   //

		//
		Application->Terminate();

	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::Timer3Timer(TObject * Sender) {
	if (Timer3->Enabled) {
		metkavis = false;
		Timer3->Enabled = false;
		HWND hWnd = GetForegroundWindow();
		bool neudalos = false;
		try {
			paste_word = GetActiveOleObject("Word.Application");
			paste_selection = paste_word.OlePropertyGet("Selection");
		}
		catch (...) {
			neudalos = true;
		}
		RE->Clear();
		RE->PasteFromClipboard();
		RE->PlainText = !RE->PlainText;
		RE->Lines->SaveToFile(ExtractFilePath(ParamStr(0)) + "temp.txt");
		RE->PlainText = !RE->PlainText;
		RE->Lines->LoadFromFile(ExtractFilePath(ParamStr(0)) + "temp.txt");
		DeleteFile(ExtractFilePath(Application->ExeName) + "temp.txt");
		AIndentNormalExecute(Sender);
		AFontNormalExecute(Sender);
		if (!Form2->CAutoFromWord->Checked) {
			return;
		}
		if (Form2->CAutoDel->Checked) {
			ADelTextExecute(Sender);
		}
		if (Form2->CAutoREgranOnOpen->Checked) {
			AModeGran->Checked = true;
			mode = true;
			AModeGranExecute(Sender);
		}
		else {
			if (Form2->AllDoc->Checked) {
				AExWordExecute(Sender);
			}
			else {
				RE->SelectAll();
				AChangeTableExecute(Form1);
				if (agdetablica) {
					agdetablica = false;
					return;
				}
				AExWordExecute(Form1);
			}
		}
		selection.OleProcedure("WholeStory");
		selection.OleProcedure("Cut");
		WideString namew("True");
		document.OlePropertySet("Saved", namew.c_bstr());
		document.OleProcedure("Close");
		word_app.OleProcedure("Quit");
		if (neudalos) {
			Sleep(300);
			ShowMessage("������� ������ � �������");
			SetForegroundWindow(hWnd);
			return;
		}
		bool exception = true;
		while (exception) {
			try {
				Sleep(15);
				paste_selection.OleProcedure("PasteAndFormat", 16);
				exception = false;
			}
			catch (...) {
			}
		}
		metkavis = true;
	}

}

// win_handle = FindWindow(L"K6ClientTopLevelFrameWindow", NULL);
// win_handle = FindWindowEx(win_handle, 0, L"AfxMDIFrame70", NULL);
// win_handle = FindWindowEx(win_handle, 0, L"AfxMDIFrame70", NULL);
// win_handle = FindWindowEx(win_handle, 0, L"AfxMDIFrame70", NULL);
// win_handle = FindWindowEx(win_handle, 0, L"AfxMDIFrame70", NULL);
// win_handle = FindWindowEx(win_handle, 0, L"AfxFrameOrView70", NULL);
// win_handle = FindWindowEx(win_handle, 0, L"_WwT", NULL);
// win_handle = FindWindowEx(win_handle, 0, L"_WwU", NULL);
// win_handle = FindWindowEx(win_handle, 0, L"_WwB", NULL);
// win_handle = FindWindowEx(win_handle, 0, L"_WwG", NULL);
//
// SendMessage(win_handle, WM_CHAR, 0x11, NULL);
void __fastcall TForm1::AClearSGExecute(TObject * Sender) {
	if (SG->RowCount < 2 && SG->ColCount < 2) {
		SG->Cells[0][0] = "";
		return;
	}
	if (MessageBox(NULL,
		L"�� �������, ��� ������ �������� �������������� �������?",
		L"������� �������", MB_YESNO + MB_ICONQUESTION + MB_TASKMODAL) == IDYES)
	{
		ochistka_tablic(SG, SGokras);
		ASwapText->Enabled = false;
	}
}

// ---------------------------------------------------------------------------
//
void __fastcall TForm1::N26Click(TObject * Sender) {
	RE->Text = ReplaceStr(RE->Text, "\r\n\r\n", "\r\n");
	defstyleRE(RE);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::N27Click(TObject * Sender) {
	REgran->Text = ReplaceStr(REgran->Text, "\r\n\r\n", "\r\n");
	defstyleRE(REgran);
}
// ---------------------------------------------------------------------------

void TForm1::threadFunction() {

}

// ---------------------------------------------------------------------------

void __fastcall TForm1::AWidthSGShortExecute(TObject * Sender) {
	widthSGFullStyle = true;
	SGColWidth();
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AWidthSGFullExecute(TObject * Sender) {
	widthSGFullStyle = false;
	SGColWidth();
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::REgranMouseWheel(TObject * Sender, TShiftState Shift,
	int WheelDelta, TPoint & MousePos, bool &Handled) {
	int num, denom;
	SendMessage(ActiveControl->Handle, EM_GETZOOM, (WPARAM) & num,
		(LPARAM) & denom);
	if (num && denom)
		StatusBar1->Panels->Items[2]->Text =
			"�������: " + FloatToStr(num * 100 / denom) + "%";
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::REKeyUp(TObject * Sender, WORD & Key, TShiftState Shift)
{
	if (((TWinControl*)ActiveControl)->Name == "RE" ||
		((TWinControl*) ActiveControl)->Name == "REgran") {
		AnsiString s = "";
		int x = ((TRichEdit*)ActiveControl)->CaretPos.X, y =
			((TRichEdit*)ActiveControl)->CaretPos.Y;
		s += "������: " + IntToStr(y + 1);
		s += " ������: " + IntToStr(x + 1);
		StatusBar1->Panels->Items[1]->Text = s;
	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::REMouseLeave(TObject * Sender) {
	bool text = false;
	for (int i = 0; i < RE->Lines->Count; i++) {
		if (!simvolstroki(RE->Lines->Strings[i]) && !simvolstolbca
			(RE->Lines->Strings[i])) {
			AnsiString s = RE->Lines->Strings[i];
			if (s != "") {
				text = true;
				break;
			}
		}
	}
	if (text) {

		AChangeNextTable->Enabled = false;
		AChangePrivTable->Enabled = false;
		if (!((TRichEdit*)ActiveControl)->SelLength) {
			AChangeTable->Enabled = false;
		}
		if (PREgran->Visible) {
			AChangeTable->Enabled = true;
		}
		ADelText->Enabled = true;
		StatusBar1->Panels->Items[3]->Text =
			"��� �������������� ��������� ���������� ������� �����";

	}
	else {
		AChangeTable->Enabled = true;
		if (memkonec == RE->Lines->Count)
			AChangeNextTable->Enabled = false;
		else {
			bool abool = false;
			for (int i = memkonec; i < RE->Lines->Count; i++) {
				if (simvolstroki(RE->Lines->Strings[i])) {
					abool = true;
					break;
				}
			}
			if (abool) {
				AChangeNextTable->Enabled = true;
			}
			else {
				AChangeNextTable->Enabled = false;
			}

		}
		if (memnachalo == 0)
			AChangePrivTable->Enabled = false;
		else
			AChangePrivTable->Enabled = true;
		if (Form2->AllDoc->Checked) {
			AExWord->Enabled = true;
		}
		ADelText->Enabled = false;
		StatusBar1->Panels->Items[3]->Text = "";

	}

}

// ---------------------------------------------------------------------------
void __fastcall TForm1::ASplitExecute(TObject * Sender) {
	bool zdesest;
	TStrings *copyregran = new TStringList;
	copyregran->Assign(REgran->Lines);

	for (int i = 0; i < copyregran->Count; i++) {
		if (!simvolstroki(copyregran->Strings[i])) {
			continue;
		}
		zdesest = false;

		for (int j = 1; j < copyregran->Strings[i].Length(); j++) {
			char simb = copyregran->Strings[i][j];
			if (isdigit(simb)) {
				zdesest = true;
				break;
			}
			else if (isalpha(simb)) {
				bool lojnayatrevoga = false;
				for (int z = 0; z < simsto->Count; z++) {
					if (simb == simsto->Strings[z][1]) {
						lojnayatrevoga = true;

					}

				}
				if (!lojnayatrevoga) {
					zdesest = true;
					break;
				}
			}
		}
		if (zdesest) {
			int ot = i;
			int kolvostolbcovtablici = 0; // ���() - �� ����� - 1 ������
			for (int k = 1; k < copyregran->Strings[ot].Length(); k++) {
				if (simvolstolbca(copyregran->Strings[ot][k])) {
					kolvostolbcovtablici++;
				}
			}
			int *posstolbcov = new int[kolvostolbcovtablici + 1];
			int numpos = 0;
			for (int k = 1; k < copyregran->Strings[ot].Length() + 1; k++) {
				if (simvolstolbca(copyregran->Strings[ot][k])) {
					posstolbcov[numpos] = k;
					numpos++;
				}
			}
			int *maxlenstolbca = new int[kolvostolbcovtablici];
			for (int k = 0; k < kolvostolbcovtablici; k++) {
				maxlenstolbca[k] = 0;
			}
			int doo;
			for (int j = ot + 1; j < copyregran->Count; j++) {
				if (!simvolstroki(copyregran->Strings[j])) {
					continue;
				}
				bool zdesnet = true;
				for (int k = 1; k < copyregran->Strings[j].Length(); k++) {
					char simb = copyregran->Strings[j][k];
					if (isdigit(simb) || isalpha(simb)) {
						zdesnet = false;
						break;
					}
				}
				if (zdesnet) {
					doo = j;
					break;
				}
			}

			for (int j = ot; j < doo; j++) {
				if (!simvolstroki(copyregran->Strings[j])) {
					continue;
				}

				for (int k = 1; k < copyregran->Strings[j].Length(); k++) {
					AnsiString simb = copyregran->Strings[j][k];
					AnsiString simb2 = copyregran->Strings[j][k + 1];
					simb += simb2;
					if (simvolstroki(simb)) {
						for (int l = 0; l < kolvostolbcovtablici; l++) {
							if (k >= posstolbcov[l] && k <= posstolbcov[l + 1])
							{
								if (maxlenstolbca[l] == 0) {
									maxlenstolbca[l] = j;
								}
								k = posstolbcov[l + 1] + 1;
								break;
							}
						}
					}
				}
			}

			for (int z = 0; z < simstr->Count; z++) {
				if (copyregran->Strings[ot].Pos(simstr->Strings[z][1])) {
					copyregran->Strings[ot] =
						ReplaceStr(copyregran->Strings[ot],
						simstr->Strings[z][1], " ");
				}

			}

			TStrings *textsledstrok = new TStringList;
			int numtextstrok = 0;
			for (int j = ot + 1; j < doo; j++) {
				textsledstrok->Add(zapolnitelstolbca);
				for (int l = 0; l < kolvostolbcovtablici; l++) {

					if (maxlenstolbca[l] == 0 || j < maxlenstolbca[l]) {
						textsledstrok->Strings[numtextstrok] +=
							dopstroka(posstolbcov[l + 1] - posstolbcov[l], " ")
							+ zapolnitelstolbca;
						continue;
					}
					textsledstrok->Strings[numtextstrok] +=
						copyregran->Strings[j].SubString(posstolbcov[l] + 1,
						posstolbcov[l + 1] - posstolbcov[l] - 1) +
						zapolnitelstolbca;
					copyregran->Strings[j] =
						copyregran->Strings[j].SubString(0, posstolbcov[l]) +
						dopstroka(posstolbcov[l + 1] - posstolbcov[l], " ") +
						copyregran->Strings[j].SubString(posstolbcov[l + 1],
						copyregran->Strings[j].Length());
				}

				numtextstrok++;

			}
			AnsiString breakline = copyregran->Strings[ot];
			for (int k = 1; k < breakline.Length(); k++) {
				bool est = false;
				for (int z = 0; z < simsto->Count; z++) {
					char a = breakline[k];
					char b = simsto->Strings[z][1];
					if (a == b) {
						est = true;
						break;
					}
				}
				if (!est) {
					breakline[k] = zapolnitelstroki[1];
				}

			}
			for (int k = 0; k < textsledstrok->Count; k++) {
				copyregran->Insert(doo + k + 1, textsledstrok->Strings[k]);
			}
			copyregran->Insert(doo + 1 + textsledstrok->Count, breakline);
			AnsiString buf1 = copyregran->Strings[doo], buf2 =
				copyregran->Strings[doo + 1 + textsledstrok->Count];
			copyregran->Strings[doo + 1 + textsledstrok->Count] = buf1;
			copyregran->Strings[doo] = buf2;
			if (i < doo) {
				i = doo;
			}

		}
	}
	REgran->Lines->Assign(copyregran);
	defstyleRE(REgran);
	// for (int l = 0; l < kolvostolbcovtablici; l++) {
	// if (maxlenstolbca[l]) {
	// bool udalstroki = true;
	// for (int j = ot + maxlenstolbca[l]; j < doo; j++) {
	// if (udalstroki) {
	// if (simvolstroki(REgran->Lines->Strings[j])) {
	// for (int z = 0; z < simstr->Count; z++) {
	// if (REgran->Lines->Strings[j].Pos
	// (simstr->Strings[z][1])) {
	// REgran->Lines->Strings[j] =
	// ReplaceStr(REgran->Lines->Strings[j],
	// simstr->Strings[z][1], " ");
	// }
	//
	// }
	// }
	// udalstroki = false;
	// }
	// else {
	//
	// }
	// }
	// }
	// else {
	// if (!l) {
	// textsledstrok->Add
	// (zapolnitelstolbca + dopstroka(posstolbcov[l + 1] -
	// posstolbcov[l], " ") + zapolnitelstolbca);
	// }
	// else {
	//
	// }
	// }
	//
	// }
	//
	// }
	// }

	// int nachalo = REgran->Perform(EM_LINEFROMCHAR, REgran->SelStart, 0);
	// int konec = REgran->Perform(EM_LINEFROMCHAR,
	// REgran->SelStart + REgran->SelLength - 1, 0);
	// if (konec - nachalo < 4) {
	// return;
	// }
	// savetomemgran();
	// AUndo->Enabled = true;
	// int gdestroka;
	// for (int i = nachalo + 1; i < konec - 1; i++) {
	// if (simvolstroki(REgran->Lines->Strings[i])) {
	// gdestroka = i;
	// break;
	// }
	// }
	// int skakogosimvola;
	// for (int i = 1; i < REgran->Lines->Strings[gdestroka].Length() - 1; i++) {
	// AnsiString a = REgran->Lines->Strings[gdestroka][i];
	// AnsiString b = REgran->Lines->Strings[gdestroka][i + 1];
	// AnsiString c = a + b;
	// if (simvolstroki(c)) {
	// skakogosimvola = i;
	// break;
	// }
	// }
	// AnsiString udalsimvstrok = REgran->Lines->Strings[gdestroka].SubString(0,
	// skakogosimvola - 1);
	// udalsimvstrok += dopstroka(REgran->Lines->Strings[gdestroka].Length() -
	// udalsimvstrok.Length(), " ") + zapolnitelstolbca;
	// REgran->Lines->Strings[gdestroka] = udalsimvstrok;
	// TStrings *textsledstrok = new TStringList;
	// for (int i = gdestroka + 1; i < konec; i++) {
	// textsledstrok->Add(REgran->Lines->Strings[i].SubString(skakogosimvola,
	// REgran->Lines->Strings[i].Length()));
	// AnsiString pervchast = REgran->Lines->Strings[i].SubString(0,
	// skakogosimvola - 1);
	// REgran->Lines->Strings[i] =
	// pervchast + dopstroka(REgran->Lines->Strings[i].Length() -
	// pervchast.Length(), " ") + zapolnitelstolbca;
	// }
	// AnsiString slepokstroki = REgran->Lines->Strings[konec].SubString(0,
	// skakogosimvola - 1);
	// for (int i = 1; i < slepokstroki.Length(); i++) {
	// if (!simvolstolbca(slepokstroki[i])) {
	// slepokstroki[i] = ' ';
	// }
	// }
	// for (int i = 0; i < textsledstrok->Count; i++) {
	// REgran->Lines->Insert(konec + i + 1,
	// slepokstroki + textsledstrok->Strings[i]);
	// }
	// REgran->Lines->Insert(konec + textsledstrok->Count + 1,
	// REgran->Lines->Strings[konec]);
	// // ����������� ���������� ������, �������� ������� ������ �� ������,
	// // ���������, �� ���������� textsledstrok ��������� ��� ������ + ����������
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::AChangeHorExecute(TObject * Sender) {
	int nachalo = REgran->Perform(EM_LINEFROMCHAR, REgran->SelStart, 0);
	int konec = REgran->Perform(EM_LINEFROMCHAR,
		REgran->SelStart + REgran->SelLength - 1, 0);
	for (int i = nachalo; i <= konec; i++) {
		for (int j = 0; j < simstr->Count; j++) {
			if (REgran->Lines->Strings[i].Pos(simstr->Strings[j][1])) {
				REgran->Lines->Strings[i] =
					ReplaceStr(REgran->Lines->Strings[i],
					simstr->Strings[j][1], " ");

			}

		}
	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::AAddColNextExecute(TObject * Sender) {
	int nachalo = REgran->Perform(EM_LINEFROMCHAR, REgran->SelStart, 0);
	if (nachalo == 0) {
		ShowMessage("�������� ���������� ��������� � ������ ������");
		return;
	}
	if (REgran->Lines->Strings[nachalo].Length() != REgran->Lines->Strings
		[nachalo - 1].Length()) {
		ShowMessage("�������� ���������� ���������. ������ ������ �����");
		return;
	}
	for (int i = 1; i < REgran->Lines->Strings[nachalo].Length() + 1; i++) {
		if (simvolstolbca(REgran->Lines->Strings[nachalo - 1][i])) {
			REgran->Lines->Strings[nachalo] =
				REgran->Lines->Strings[nachalo].SubString(1, i - 1) +
				zapolnitelstolbca + REgran->Lines->Strings[nachalo].SubString
				(i + 1, REgran->Lines->Strings[nachalo].Length());
		}
	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::AAddColPrivExecute(TObject * Sender) {
	int nachalo = REgran->Perform(EM_LINEFROMCHAR, REgran->SelStart, 0);
	if (nachalo == REgran->Lines->Count) {
		ShowMessage("�������� ���������� ��������� � ��������� ������");
		return;
	}
	if (REgran->Lines->Strings[nachalo].Length() != REgran->Lines->Strings
		[nachalo + 1].Length()) {
		ShowMessage("�������� ���������� ���������. ������ ������ �����");
		return;
	}
	for (int i = 1; i < REgran->Lines->Strings[nachalo].Length() + 1; i++) {
		if (simvolstolbca(REgran->Lines->Strings[nachalo + 1][i])) {
			REgran->Lines->Strings[nachalo] =
				REgran->Lines->Strings[nachalo].SubString(1, i - 1) +
				zapolnitelstolbca + REgran->Lines->Strings[nachalo].SubString
				(i + 1, REgran->Lines->Strings[nachalo].Length());
		}
	}
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AAllocRowExecute(TObject * Sender) {

	TGridRect hGridRect;
	hGridRect.Top = SG->Selection.Top;
	hGridRect.Left = 0;
	hGridRect.Right = SG->ColCount;
	hGridRect.Bottom = SG->Selection.Bottom;
	SG->Selection = hGridRect;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AAllocColExecute(TObject * Sender) {

	TGridRect hGridRect;
	hGridRect.Top = 0;
	hGridRect.Left = SG->Selection.Left;
	hGridRect.Right = SG->Selection.Right;
	hGridRect.Bottom = SG->RowCount;
	SG->Selection = hGridRect;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::AAllocAllExecute(TObject * Sender) {
	TGridRect hGridRect;
	hGridRect.Top = 0;
	hGridRect.Left = 0;
	hGridRect.Right = SG->ColCount;
	hGridRect.Bottom = SG->RowCount;
	SG->Selection = hGridRect;
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::ASwapTextExecute(TObject * Sender) {
	int maxcolcount = SG->ColCount, maxcolposstring = 0;
	for (int i = 0; i < memchangetable->Count; i++) {
		int maxcolthisstring = 0;
		for (int j = 1; j < memchangetable->Strings[i].Length() + 1; j++) {
			if (simvolstolbca(REgran->Lines->Strings[i][j])) {
				maxcolthisstring++;
			}
		}
		if (maxcolthisstring - 1 == maxcolcount) {
			maxcolposstring = i;
			break;
		}
	}
	int *mascolpos = new int[maxcolcount];
	int k = 0;
	for (int j = 1; j < memchangetable->Strings[maxcolposstring].Length(); j++)
	{
		if (simvolstolbca(REgran->Lines->Strings[maxcolposstring][j])) {
			mascolpos[k] = j;
			k++;
		}
	}

	int row = 0;
	for (int i = 1; i < memchangetable->Count - 1; i++) {
		if (simvolstroki(memchangetable->Strings[i])) {
			row++;
			continue;
		}
		int maxcolthisstring = 0;
		int *masthisstringSGpos = new int[maxcolcount];
		int kk = 0, sgk = 0;
		for (int j = 1; j < memchangetable->Strings[i].Length(); j++) {
			if (simvolstolbca(REgran->Lines->Strings[i][j])) {

				while (j != mascolpos[kk] && kk < maxcolcount) {
					kk++;
				}
				if (kk >= maxcolcount) {
					kk = maxcolcount - 1;
				}
				masthisstringSGpos[sgk] = kk;
				sgk++;
				kk++;
			}
		}

		bool metka = false;
		for (int h = sgk - 1; h >= 0; h--) {
			int zxc = masthisstringSGpos[h];
			if (zxc == h) {
				if (metka) {
					if (SG->Cells[zxc][row] != "") {
						for (int z = zxc; z < masthisstringSGpos[h + 1]; z++) {
							if (SG->Cells[z + 1][row] == "") {
								SGokras->Cells[z][row] = "1";
								SGokras->Cells[z + 1][row] = "1";
							}
						}
					}
					metka = false;
				}
				continue;
			}
			SG->Cells[zxc][row] = SG->Cells[h][row];
			SG->Cells[h][row] = "";
			if (h == sgk - 1) {
				if (SG->Cells[zxc][row] != "") {
					for (int z = zxc; z < SG->ColCount - 1; z++) {
						if (SG->Cells[z + 1][row] == "") {
							SGokras->Cells[z][row] = "1";
							SGokras->Cells[z + 1][row] = "1";
						}
					}
				}
			}
			else {
				if (SG->Cells[zxc][row] != "") {
					for (int z = zxc; z < masthisstringSGpos[h + 1]; z++) {
						if (SG->Cells[z + 1][row] == "") {
							SGokras->Cells[z][row] = "1";
							SGokras->Cells[z + 1][row] = "1";
						}
					}
				}
			}
			metka = true;
		}

		while (!simvolstroki(memchangetable->Strings[i]) && i <
			memchangetable->Count - 2) {
			i++;
		}
		i--;
		delete[]masthisstringSGpos;
	}
	ASwapText->Enabled = false;
	perekras();
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::AMergeRectExecute(TObject * Sender) {
	// �����
	if (SG->Selection.Top == SG->Selection.Bottom) {
		ShowMessage("�������� ����� ���� �����");
		return;
	}
	if (SG->Selection.Left == SG->Selection.Right) {
		ShowMessage("�������� ����� ���� ��������");
		return;
	}
	for (int i = SG->Selection.Left; i <= SG->Selection.Right; i++) {
		for (int j = SG->Selection.Top; j <= SG->Selection.Bottom; j++) {
			SGokras->Cells[i][j] = 3;
		}
	}
	perekras();
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::ComboBox1Select(TObject *Sender) {
	Form2->CMode->ItemIndex = ComboBox1->ItemIndex;
	Form2->Readini(false);
	if (ComboBox1->ItemIndex != Form2->CMode->ItemIndex) {
		ComboBox1->ItemIndex = Form2->CMode->ItemIndex;
	}
}
// ---------------------------------------------------------------------------
