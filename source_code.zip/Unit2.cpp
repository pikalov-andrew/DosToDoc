// ---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "Unit1.h"
#include "Unit2.h"
#include <memory>
#include "IniFiles.hpp"
#include "Registry.hpp"

// ---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
TIniFile *iniFile;

// ---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner) : TForm(Owner) {
	TStrings *zagruzka = new TStringList;
	iniFile = new TIniFile(ExtractFilePath(Application->ExeName) +
		"symbols.ini");
	TStringList *iniSections = new TStringList;
	iniFile->ReadSections(iniSections);
	if (!iniSections->Count) {
		Writeini(true);
		Readini(false);
	}
	else {
		Readini(true);
	}
	Form1->zapolniteli();
	Form1->ComboBox1->ItemIndex = CMode->ItemIndex;
}

// ---------------------------------------------------------------------------

void __fastcall TForm2::CheckBoxes() {
	if (Form2->CAutoDel->Checked == true &&
		Form2->CAutoREgranOnPaste->Checked == true &&
		Form2->CAutoREgranOnOpen->Checked == true &&

		Form2->CAutoFromWord->Checked == true &&

		Form2->OneDoc->Checked == true && Form2->AllDoc->Checked == true &&
		Form2->CAutoExWordREgran->Checked == true &&

		Form2->CAutoMerge->Checked == true && Form2->CUnmergeBorders->Checked ==
		true && Form2->CCopyBorders->Checked == true &&
		Form2->CAutoSwapText->Checked == true &&
		Form2->CAutoLimit->Checked == true) {
		CMode->ItemIndex = 0;
	}
	else if (Form2->CAutoDel->Checked == true &&
		Form2->CAutoREgranOnPaste->Checked == false &&
		Form2->CAutoREgranOnOpen->Checked == false &&

		Form2->CAutoFromWord->Checked == true &&

		Form2->OneDoc->Checked == true && Form2->AllDoc->Checked == true &&
		Form2->CAutoExWordREgran->Checked == false &&

		Form2->CAutoMerge->Checked == false &&
		Form2->CUnmergeBorders->Checked == false &&
		Form2->CCopyBorders->Checked == false &&
		Form2->CAutoSwapText->Checked == false && Form2->CAutoLimit->Checked ==
		false) {
		CMode->ItemIndex = 1;
		Form1->ComboBox1->ItemIndex = 1;
	}
	else if (Form2->CAutoDel->Checked == false &&
		Form2->CAutoREgranOnPaste->Checked == false &&
		Form2->CAutoREgranOnOpen->Checked == false &&

		Form2->CAutoFromWord->Checked == true &&

		Form2->OneDoc->Checked == true && Form2->AllDoc->Checked == false &&
		Form2->CAutoExWordREgran->Checked == false &&

		Form2->CAutoMerge->Checked == false &&
		Form2->CUnmergeBorders->Checked == false &&
		Form2->CCopyBorders->Checked == false &&
		Form2->CAutoSwapText->Checked == false && Form2->CAutoLimit->Checked ==
		false) {
		CMode->ItemIndex = 2;
		Form1->ComboBox1->ItemIndex = 2;
	}
	else {
		CMode->ItemIndex = 3;
		Form1->ComboBox1->ItemIndex = 3;
	}
}

void __fastcall TForm2::Readini(bool def) {

	UnicodeString s = "";
	if (def) {
		s = iniFile->ReadString("mode", "mode",
			"�������������� ��������� ������");
	}
	else
		s = CMode->Text;

	if (s == "�������������� ��������� ������") {
		CMode->ItemIndex = 0;
		Form2->CAutoDel->Checked = true;
		Form2->CAutoREgranOnPaste->Checked = true;
		Form2->CAutoREgranOnOpen->Checked = true;

		Form2->CAutoFromWord->Checked = true;

		Form2->OneDoc->Checked = true;
		Form2->AllDoc->Checked = true;
		Form2->CAutoExWordREgran->Checked = true; //

		Form2->CAutoMerge->Checked = true;
		Form2->CUnmergeBorders->Checked = true;
		Form2->CCopyBorders->Checked = true;
		Form2->CAutoSwapText->Checked = true; //
		Form2->CAutoLimit->Checked = true; //
	}
	else if (s == "�������������� ��������� ������") {
		CMode->ItemIndex = 1;
		Form2->CAutoDel->Checked = true;
		Form2->CAutoREgranOnPaste->Checked = false;
		Form2->CAutoREgranOnOpen->Checked = false;

		Form2->CAutoFromWord->Checked = true;

		Form2->OneDoc->Checked = true;
		Form2->AllDoc->Checked = true;
		Form2->CAutoExWordREgran->Checked = false; //

		Form2->CAutoMerge->Checked = false;
		Form2->CUnmergeBorders->Checked = false;
		Form2->CCopyBorders->Checked = false;
		Form2->CAutoSwapText->Checked = false; //
		Form2->CAutoLimit->Checked = false; //
	}
	else if (s == "��������������� ��������� ������") {
		CMode->ItemIndex = 2;
		Form2->CAutoDel->Checked = false;
		Form2->CAutoREgranOnPaste->Checked = false;
		Form2->CAutoREgranOnOpen->Checked = false;

		Form2->CAutoFromWord->Checked = true;

		Form2->OneDoc->Checked = true;
		Form2->AllDoc->Checked = false;
		Form2->CAutoExWordREgran->Checked = false; //

		Form2->CAutoMerge->Checked = false;
		Form2->CUnmergeBorders->Checked = false;
		Form2->CCopyBorders->Checked = false;
		Form2->CAutoSwapText->Checked = false; //
		Form2->CAutoLimit->Checked = false; //
	}
	else {
		CMode->ItemIndex = 3;

		Form2->CAutoDel->Checked =
			iniFile->ReadBool("loading", "deletetext", false);
		Form2->CAutoREgranOnPaste->Checked =
			iniFile->ReadBool("loading", "onpaste", false); //
		Form2->CAutoREgranOnOpen->Checked =
			iniFile->ReadBool("loading", "onopen", false); //

		Form2->CAutoFromWord->Checked =
			iniFile->ReadBool("context", "contextautoexecute", false);

		Form2->OneDoc->Checked = iniFile->ReadBool("converting",
			"toonedoc", false);
		Form2->AllDoc->Checked = iniFile->ReadBool("converting",
			"alltable", false);
		Form2->CAutoExWordREgran->Checked =
			iniFile->ReadBool("converting", "autoexecuteregran", false); //

		Form2->CAutoMerge->Checked =
			iniFile->ReadBool("merge", "deleterowscols", false);
		Form2->CUnmergeBorders->Checked =
			iniFile->ReadBool("merge", "autounmerge", false);
		Form2->CCopyBorders->Checked =
			iniFile->ReadBool("merge", "autocopyborders", false);
		Form2->CAutoSwapText->Checked =
			iniFile->ReadBool("merge", "autoswaptext", false); //
		Form2->CAutoLimit->Checked = iniFile->ReadBool("merge", "autolimit",
			false); //
	}
	Form2->RowSymbols->Text = iniFile->ReadString("symbols", "row", "--,��");
	Form2->ColSymbols->Text = iniFile->ReadString("symbols", "column",
		"|,T,�,+,�,L");

	Form2->CDoMacro->Checked = iniFile->ReadBool("converting",
		"playmacro", false);
	Form2->MacroName->Text = iniFile->ReadString("converting", "macroname", "");
}

void __fastcall TForm2::Writeini(bool def) {
	if (def) {

		iniFile->WriteString("mode", "mode", "�������������� ��������� ������");

		iniFile->WriteBool("loading", "deletetext", false);
		iniFile->WriteBool("loading", "onpaste", false);
		iniFile->WriteBool("loading", "onopen", false);

		iniFile->WriteBool("context", "contextautoexecute", false);

		iniFile->WriteString("symbols", "row", "--,��");
		iniFile->WriteString("symbols", "column", "|,T,�,+,�,L");

		iniFile->WriteBool("merge", "deleterowscols", false);
		iniFile->WriteBool("merge", "autounmerge", false);
		iniFile->WriteBool("merge", "autocopyborders", false);
		iniFile->WriteBool("merge", "autoswaptext", false); //
		iniFile->WriteBool("merge", "autolimit", false); //

		iniFile->WriteBool("converting", "toonedoc", false);
		iniFile->WriteBool("converting", "alltable", false);
		iniFile->WriteBool("converting", "autoexecuteregran", false);
		iniFile->WriteBool("converting", "playmacro", false);
		iniFile->WriteString("converting", "macroname", "");

		iniFile->UpdateFile();
	}
	else {
		iniFile->WriteString("mode", "mode", CMode->Text);
		if (CMode->ItemIndex == 3) {
			iniFile->WriteBool("loading", "deletetext",
			Form2->CAutoDel->Checked);
			iniFile->WriteBool("loading", "onpaste",
				Form2->CAutoREgranOnPaste->Checked);
			iniFile->WriteBool("loading", "onopen",
				Form2->CAutoREgranOnOpen->Checked);

			iniFile->WriteBool("context", "contextautoexecute",
				Form2->CAutoFromWord->Checked);

			iniFile->WriteString("symbols", "row", Form2->RowSymbols->Text);
			iniFile->WriteString("symbols", "column", Form2->ColSymbols->Text);

			iniFile->WriteBool("merge", "deleterowscols",
				Form2->CAutoMerge->Checked);
			iniFile->WriteBool("merge", "autounmerge",
				Form2->CUnmergeBorders->Checked);
			iniFile->WriteBool("merge", "autocopyborders",
				Form2->CCopyBorders->Checked);
			iniFile->WriteBool("merge", "autoswaptext",
				Form2->CAutoSwapText->Checked); //
			iniFile->WriteBool("merge", "autolimit",
				Form2->CAutoLimit->Checked); //

			iniFile->WriteBool("converting", "toonedoc",
				Form2->OneDoc->Checked);
			iniFile->WriteBool("converting", "alltable",
				Form2->AllDoc->Checked);
			iniFile->WriteBool("converting", "autoexecuteregran",
				Form2->CAutoExWordREgran->Checked);
			iniFile->WriteBool("converting", "playmacro",
				Form2->CDoMacro->Checked);
			iniFile->WriteString("converting", "macroname",
				Form2->MacroName->Text);

			iniFile->UpdateFile();
		}
	}
}

void __fastcall TForm2::BSaveParamClick(TObject *Sender) {
	Writeini(false);
	ShowMessage("��������� ���������");
	Form2->Close();
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::BUndoParamClick(TObject *Sender) {
	Readini(false);
	ShowMessage("��������� �������������");
	Form2->Close();
}
// ---------------------------------------------------------------------------
Variant word_appp;

// ---------------------------------------------------------------------------

void __fastcall TForm2::ResetContClick(TObject *Sender) {
	word_appp = CreateOleObject("Word.Application");
	WideString macrw("ResetConttrol");
	word_appp.OleFunction("Run", macrw.c_bstr());
	word_appp.OleProcedure("Quit");
	ShowMessage("����������� ���� ���������� � �������� ���������");

}
// ---------------------------------------------------------------------------

void __fastcall TForm2::ContWordClick(TObject *Sender) {
	word_appp = CreateOleObject("Word.Application");
	WideString macrw("AddConttrolDosToDoc");
	word_appp.OleFunction("Run", macrw.c_bstr());
	word_appp.OleProcedure("Quit");
	ShowMessage(
		"� ����������� ���� Word �������� ����� \"������������� �������\"");
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::CModeSelect(TObject *Sender) {
	Readini(false);
	Form1->ComboBox1->ItemIndex = CMode->ItemIndex;
}

// ---------------------------------------------------------------------------
void __fastcall TForm2::CAutoREgranOnPasteClick(TObject *Sender) {
	CheckBoxes();
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::CAutoREgranOnOpenClick(TObject *Sender) {
	CheckBoxes();
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::CAutoFromWordClick(TObject *Sender) {
	CheckBoxes();
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::CAutoLimitClick(TObject *Sender) {
	CheckBoxes();
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::CAutoSwapTextClick(TObject *Sender) {
	CheckBoxes();
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::CAutoMergeClick(TObject *Sender) {
	CheckBoxes();
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::CCopyBordersClick(TObject *Sender) {
	CheckBoxes();
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::CAutoDelClick(TObject *Sender) {
	CheckBoxes();
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::CUnmergeBordersClick(TObject *Sender) {
	CheckBoxes();
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::AllDocClick(TObject *Sender) {
	CheckBoxes();
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::OneDocClick(TObject *Sender) {
	CheckBoxes();
}
// ---------------------------------------------------------------------------

void __fastcall TForm2::CAutoExWordREgranClick(TObject *Sender) {
	CheckBoxes();
}
// ---------------------------------------------------------------------------
